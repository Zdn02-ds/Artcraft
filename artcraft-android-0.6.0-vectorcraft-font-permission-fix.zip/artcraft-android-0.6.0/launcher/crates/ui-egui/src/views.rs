//! The header, toolbar, footer, the grid of cards and the table, laid out like the apps page on
//! getartcraft.com: hairline cells, mono labels and square controls.

use artcraft_launcher_core::catalog::AppKind;
use artcraft_launcher_core::details::AppDetails;
use artcraft_launcher_core::platform::pick_asset;
use artcraft_launcher_core::protocol::{Command, JobPhase};
use artcraft_launcher_core::status::AppStatus;
use artcraft_launcher_core::time;
use egui::{Color32, CornerRadius, FontId, Rect, RichText, Sense, Stroke, Ui, vec2};

use crate::app::{Dialog, LauncherUi, TitleBar};
use crate::i18n::{current, fmt, t, tn, tr_ctx};
use crate::model::{self, AppEntry};
use crate::settings::{Filter, SortKey, ViewMode};
use crate::theme::{self, Tokens, rgb, tint};
use crate::widgets::{self, Kind};

/// The byline that says who makes an app: "by ArtCraft" or "by <publisher>". Official apps take
/// the accent colour, community apps the muted one.
fn kind_badge(ui: &mut Ui, app: &artcraft_launcher_core::CraftApp, t: &Tokens) {
    let text = fmt(tl!("by {name}"), &[("name", app.publisher)]);
    let color = match app.kind {
        AppKind::Official => t.accent_ink,
        AppKind::Community => t.muted,
    };
    widgets::badge(ui, &text, color);
}

/// Translate a relative timestamp ("just now", "5 min ago", …) into the current language.
fn ago_text(secs: i64, now: i64) -> String {
    match time::ago_kind(secs, now) {
        time::TimeAgo::JustNow => t("just now").to_string(),
        time::TimeAgo::Minutes(n) => tn(n, "{n} min ago", "{n} min ago"),
        time::TimeAgo::Hours(n) => tn(n, "{n} h ago", "{n} h ago"),
        time::TimeAgo::Yesterday => t("yesterday").to_string(),
        time::TimeAgo::Days(n) => tn(n, "{n} day ago", "{n} days ago"),
        time::TimeAgo::Date(secs) => date_text(secs),
    }
}

/// `long`, or the first of `shorter` whose button fits `width` (the last one if none does): a
/// wider button would push the `⋯` menu beside it out of the row (#956). The table's version
/// column and the card's top strip show the version, so the shorter labels can leave it out.
fn fitted<'a>(ui: &Ui, long: &'a str, shorter: &[&'a str], width: f32) -> &'a str {
    std::iter::once(long)
        .chain(shorter.iter().copied())
        .find(|label| widgets::button_width(ui, label, 0.0) <= width)
        .or_else(|| shorter.last().copied())
        .unwrap_or(long)
}

/// Translate an absolute date ("Oct 8, 2026" → "8 окт. 2026") into the current language, on this
/// computer's calendar (`local_time`). Every date the launcher shows is written by this.
pub(crate) fn date_text(secs: i64) -> String {
    let (y, m, d) = crate::local_time::civil(secs);
    let month = tr_ctx(current(), "month", time::month_short_en(m));
    fmt(tl!("{month} {day}, {year}"), &[("month", month), ("day", &d.to_string()), ("year", &y.to_string())])
}

/// What the main button of an app does.
enum Primary {
    Install,
    /// The download is already here; only the install step is left. Carries the button's label
    /// and shorter ones for when it doesn't fit.
    Retry(String, Vec<&'static str>),
    Update(String),
    /// A pinned release only installs after the backend has checked that exact tag.
    SelectedVersion {
        tag: String,
        checked: bool,
    },
    Open,
    Download(String),
    Unavailable(&'static str),
}

/// Where an app's actions are drawn.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Place {
    /// A grid card, at a fixed height.
    Card,
    /// A table row, which grows to stack an update's split where it can't sit side by side.
    Row,
    /// The details page, which shows the website and repository links as buttons of its own.
    Details,
}

impl Place {
    /// Whether the `⋯` menu holds the website, repository and releases links.
    fn links_in_menu(self) -> bool {
        self != Self::Details
    }
}

/// What an update's install half says: its full label, shorter ones for less room, and a tooltip.
struct UpdateLabels {
    label: String,
    shorter: Vec<&'static str>,
    tip: Option<&'static str>,
}

impl UpdateLabels {
    /// The labels when `primary` installs an update or retries one; `None` otherwise.
    fn of(primary: Primary) -> Option<Self> {
        match primary {
            Primary::Retry(label, shorter) => {
                Some(Self { label, shorter, tip: Some(tl!("The download is still here. It's checked again, then installed.")) })
            }
            Primary::Update(v) => Some(Self { label: fmt(tl!("Update to {v}"), &[("v", &v)]), shorter: vec![tl!("Update")], tip: None }),
            _ => None,
        }
    }
}

/// The Open half beside a waiting update: its label, naming the installed version, and what it
/// does in full (its tooltip and accessible name). `None` unless an installed copy waits for an
/// update.
fn open_labels(entry: &AppEntry, status: &AppStatus) -> Option<(String, String)> {
    let (installed, latest) = (*status == AppStatus::UpdateAvailable).then(|| entry.installed_label().zip(entry.latest_label())).flatten()?;
    let open = fmt(tl!("Open {version}"), &[("version", &installed)]);
    let about = fmt(tl!("Open {installed} without updating. {latest} stays available."), &[("installed", &installed), ("latest", &latest)]);
    Some((open, about))
}

/// How Open (`open`, then plain "Open") and an update (`update`) share `main_w` in `place`: side
/// by side, stacked in a table row, or `None` for the update alone.
fn update_split<'a>(ui: &Ui, place: Place, main_w: f32, open: &'a str, update: &'a UpdateLabels) -> Option<widgets::Split<'a>> {
    let rights: Vec<&str> = std::iter::once(update.label.as_str()).chain(update.shorter.iter().copied()).collect();
    widgets::split_layout(ui, main_w, &[open, tl!("Open")], &rights, place == Place::Row)
}

/// Why a newer release noted beside an installed copy isn't offered as an update: `newer` from
/// [`LauncherUi::out_of_reach`].
fn out_of_reach_tip(newer: Option<String>) -> Option<String> {
    Some(fmt(tl!("{latest} is out, but ArtCraft Launcher can't install it over this copy."), &[("latest", &newer?)]))
}

/// The width of the main button: what's left of `width` beside the square `⋯` menu.
fn main_width(ui: &Ui, width: f32) -> f32 {
    (width - theme::CONTROL_H - ui.spacing().item_spacing.x).max(120.0)
}

/// The width of a table row's actions, after a pinned row's grip.
const TABLE_ACTIONS_W: f32 = 204.0;
/// The height of a table row.
const TABLE_ROW_H: f32 = 62.0;

/// Height of the header bar (the site's nav).
pub(crate) const HEADER_H: f32 = 48.0;
/// Height of the footer bar.
pub(crate) const FOOTER_H: f32 = 34.0;

const CARD_MIN_W: f32 = 320.0;
const CARD_H: f32 = 314.0;
/// The app column's name and tagline sizes, to centre them on the icon.
const TITLE_SIZE: f32 = 16.0;
const TAGLINE_SIZE: f32 = 12.0;
/// The card's top strip: number tab and links.
const STRIP_H: f32 = 40.0;
const CARD_PAD: f32 = 20.0;
/// Room macOS's traffic lights take at the left of the header.
const TRAFFIC_LIGHTS_W: f32 = 72.0;

impl LauncherUi {
    /// The header bar; with a custom or macOS title bar it is also the window's title bar.
    pub(crate) fn header(&mut self, ui: &mut Ui, bar: TitleBar) {
        let t = Tokens::get(ui.ctx());
        let h = HEADER_H;
        if bar != TitleBar::Native {
            widgets::title_bar_drag(ui);
        }
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 0.0;
            if bar == TitleBar::MacOs {
                ui.add_space(TRAFFIC_LIGHTS_W);
            }
            // The ArtCraft wordmark exactly as supplied, in its own cell.
            let logo = vec2(6.0 * crate::icons::ARTCRAFT_LOGO_ASPECT, 6.0);
            let (cell, _) = ui.allocate_exact_size(vec2(logo.x + 30.0, h), Sense::hover());
            egui::Image::new(crate::icons::artcraft_logo(t.dark)).alt_text(tl!("ArtCraft")).paint_at(ui, Rect::from_center_size(cell.center(), logo));
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if bar == TitleBar::Custom {
                    widgets::window_buttons(ui, h);
                }
                if widgets::nav_icon(ui, widgets::Glyph::Settings, tl!("Settings"), h, false).clicked() {
                    self.dialog = Some(Dialog::Settings);
                }
                // The controls reserve their actual widths before the secondary text gets space.
                ui.with_layout(egui::Layout::left_to_right(egui::Align::Center), |ui| {
                    if ui.available_width() >= 17.0 + widgets::hud_galley(ui, tl!("Craft App Suite"), t.muted).size().x {
                        widgets::rule(ui, h);
                        ui.add_space(16.0);
                        widgets::hud(ui, tl!("Craft App Suite"), t.muted);
                    }
                });
            });
        });
    }

    pub(crate) fn toolbar(&mut self, ui: &mut Ui) {
        if self.settings.filter == Filter::Hidden && self.settings.hidden.is_empty() {
            self.settings.filter = Filter::All;
        }
        let t = Tokens::get(ui.ctx());
        if self.dialog.is_none()
            && let Some(r) = self.launcher_update.clone()
        {
            self.launcher_update_banner(ui, &t, &r);
            ui.add_space(14.0);
        }
        self.announcements(ui);
        let updates = self.count(Filter::Updates);
        self.toolbar_row(ui, &t, updates);
    }

    /// A banner over the toolbar when a newer ArtCraft Launcher release is known: either the
    /// update-in-place controls, or a plain link when this build can't update itself.
    fn launcher_update_banner(&mut self, ui: &mut Ui, t: &Tokens, r: &artcraft_launcher_core::Release) {
        egui::Frame::new()
            .fill(tint(t.accent, if t.dark { 0.10 } else { 0.07 }))
            .stroke(Stroke::new(1.0, tint(t.accent, 0.6)))
            .inner_margin(egui::Margin::symmetric(16, 10))
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    widgets::tag(ui, tl!("Update"), t.accent, Color32::WHITE);
                    ui.add_space(4.0);
                    ui.label(
                        RichText::new(fmt(tl!("ArtCraft Launcher {version} is available."), &[("version", &r.version_label())]))
                            .family(theme::medium())
                            .color(t.ink_strong),
                    );
                    self.banner_actions(ui, t, r);
                });
            });
    }

    /// The banner's right side: the download's progress and cancel while it runs, otherwise the
    /// update (or download) buttons plus the release link.
    fn banner_actions(&mut self, ui: &mut Ui, t: &Tokens, r: &artcraft_launcher_core::Release) {
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if let Some(phase) = self.launcher_job {
                let (fraction, caption) = match phase {
                    JobPhase::Downloading { done, total } if total > 0 => (
                        Some(done as f32 / total as f32),
                        fmt(tl!("Downloading {done} of {total}"), &[("done", &widgets::human_bytes(done)), ("total", &widgets::human_bytes(total))]),
                    ),
                    JobPhase::Downloading { .. } | JobPhase::Reconnecting { .. } => (None, tl!("Downloading…").to_string()),
                    JobPhase::Verifying => (None, tl!("Verifying…").to_string()),
                    JobPhase::Waiting => (None, tl!("Waiting for other installs…").to_string()),
                    JobPhase::Installing | JobPhase::Removing => (None, tl!("Installing, then restarting…").to_string()),
                };
                // Another app's install can hang on a password prompt: the wait can be called off.
                if phase == JobPhase::Waiting
                    && widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Cancel update"))
                        .on_hover_text(tl!("Stop waiting; the update can be started again later"))
                        .clicked()
                {
                    self.act_command(Command::Cancel { app: artcraft_launcher_core::catalog::LAUNCHER_ID.to_string() });
                }
                widgets::progress(ui, fraction, &caption, t.accent, 220.0);
                return;
            }
            if widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Dismiss")).clicked() {
                self.launcher_update = None;
            }
            if self.caps.self_update {
                if widgets::button(ui, tl!("Update and restart"), Kind::Primary, 0.0)
                    .on_hover_text(tl!("Downloads the new version, replaces this one and opens it again"))
                    .clicked()
                {
                    self.act_command(Command::UpdateLauncher);
                }
            } else {
                let url =
                    self.platform.and_then(|p| launcher_download(r, p, crate::settings::is_flatpak_sandbox())).unwrap_or_else(|| r.html_url.clone());
                if widgets::button(ui, tl!("Download"), Kind::Primary, 0.0).clicked() {
                    widgets::open_external_link(ui.ctx(), &url);
                }
            }
            ui.add_space(8.0);
            widgets::hud_link(ui, tl!("What's new"), &r.html_url);
        });
    }

    /// The toolbar's main row: the refresh button, the hidden-apps toggle, the view switch, the
    /// search field. Returns whether the window is narrow enough that a second row follows.
    fn toolbar_row(&mut self, ui: &mut Ui, _t: &Tokens, _updates: usize) -> bool {
        let mut compact = false;
        ui.horizontal(|ui| {
            // Hiding an app is only undone from here, so the way back to the hidden ones stays
            // while there are any: a toggle, lit while the hidden apps are what the page shows.
            if !self.settings.hidden.is_empty() {
                let showing = self.settings.filter == Filter::Hidden;
                let label = format!("{} {}", tl!("Hidden Apps"), self.settings.hidden.len());
                if widgets::button(ui, &label, if showing { Kind::Primary } else { Kind::Secondary }, 0.0)
                    .on_hover_text(tl!("Apps you hid"))
                    .clicked()
                {
                    self.settings.filter = if showing { Filter::All } else { Filter::Hidden };
                }
            }
            compact = ui.available_width() < theme::TOOLBAR_COMPACT_BELOW;
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                // Right to left: the view switch at the far right, then the search.
                crate::bar::view_toggle(ui, &mut self.settings.view, [tl!("Show apps as cards"), tl!("Show apps as a table")]);
                ui.add_space(4.0);
                ui.add(
                    egui::TextEdit::singleline(&mut self.search)
                        .hint_text(tl!("Search apps"))
                        .desired_width(200.0)
                        .min_size(vec2(0.0, theme::CONTROL_H))
                        .align(egui::Align2::LEFT_CENTER)
                        .margin(vec2(10.0, 0.0)),
                )
                .accessible_name(tl!("Search apps"));
            });
        });
        compact
    }

    /// The toolbar's second row on narrow windows: just the search field.
    fn toolbar_compact_row(&mut self, ui: &mut Ui, _t: &Tokens, _updates: usize) {
        ui.add_space(6.0);
        ui.horizontal(|ui| {
            ui.add(
                egui::TextEdit::singleline(&mut self.search)
                    .hint_text(tl!("Search apps"))
                    .desired_width(200.0)
                    .min_size(vec2(0.0, theme::CONTROL_H))
                    .align(egui::Align2::LEFT_CENTER)
                    .margin(vec2(10.0, 0.0)),
            )
            .accessible_name(tl!("Search apps"));
        });
    }

    /// The toolbar's check button. It queues a forced check through the UI action boundary and is
    /// disabled while `self.checking`; the backend receives the check only when this pass flushes.
    fn refresh_button(&mut self, ui: &mut Ui) {
        if crate::bar::refresh_button(ui, tl!("Check for updates"), self.checking).clicked() {
            self.check_now_from_ui();
        }
    }

    /// The grid's sort combo box. It writes the chosen key and direction directly (not through the
    /// action queue) and carries an accessible "Sort" name.
    fn sort_picker(&mut self, ui: &mut Ui) {
        craft_ui::ComboBox::from_id_salt("sort")
            .selected_text(RichText::new(grid_sort_label(grid_sort_now(&self.settings))).size(13.0))
            .width(190.0)
            .show_ui(ui, |ui| {
                let current = grid_sort_now(&self.settings);
                for choice in GRID_SORTS {
                    if ui.selectable_label(current == choice, grid_sort_label(choice)).clicked() {
                        self.settings.sort = choice.0;
                        self.settings.sort_descending = choice.1;
                    }
                }
            })
            .response
            .accessible_name(tl!("Sort"));
    }

    /// Update every eligible app; used in the compact and full-width toolbars.
    fn update_all_button(&mut self, ui: &mut Ui, updates: usize) {
        let label = if updates == 1 { tl!("Update 1 app").to_string() } else { fmt(tl!("Update all ({count})"), &[("count", &updates.to_string())]) };
        if widgets::button(ui, &label, Kind::Primary, 0.0).clicked() {
            let ids: Vec<&str> = self.entries.iter().filter(|e| self.in_filter(e, Filter::Updates) && e.job.is_none()).map(|e| e.app.id).collect();
            for id in ids {
                self.act_command(Command::Install { app: id.to_string() });
            }
        }
    }

    /// News from ArtCraft's release feed (and app renames), until the user dismisses each.
    fn announcements(&mut self, ui: &mut Ui) {
        let t = Tokens::get(ui.ctx());
        let shown: Vec<artcraft_launcher_core::feed::Notice> =
            self.announcements.iter().filter(|n| !self.settings.dismissed_notices.contains(&n.id)).take(3).cloned().collect();
        for notice in shown {
            egui::Frame::new().fill(t.sunken).stroke(t.hairline()).inner_margin(egui::Margin::symmetric(14, 10)).show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Min), |ui| {
                        if widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Dismiss")).clicked() {
                            self.settings.dismissed_notices.insert(notice.id.clone());
                        }
                        if let Some(link) = &notice.link {
                            widgets::hud_link(ui, tl!("Learn more"), link);
                        }
                        ui.with_layout(egui::Layout::top_down(egui::Align::Min), |ui| {
                            ui.spacing_mut().item_spacing.y = 2.0;
                            if !notice.title.is_empty() {
                                ui.label(RichText::new(&notice.title).family(theme::semibold()).color(t.ink_strong));
                            }
                            if !notice.body.is_empty() {
                                ui.add(egui::Label::new(RichText::new(&notice.body).color(t.muted)).wrap());
                            }
                        });
                    });
                });
            });
            ui.add_space(8.0);
        }
    }

    pub(crate) fn footer(&mut self, ui: &mut Ui) {
        let t = Tokens::get(ui.ctx());
        let now = self.backend.now();
        let status = if self.checking {
            tl!("Checking for updates…").to_string()
        } else if let Some(at) = self.settings.last_check {
            let ago = ago_text(at, now);
            match self.sources_label() {
                Some(using) => fmt(tl!("Checked {ago} · using {sources}"), &[("ago", &ago), ("sources", &using)]),
                None => fmt(tl!("Checked {ago}"), &[("ago", &ago)]),
            }
        } else {
            tl!("Not checked yet").to_string()
        };
        // The full notice, and a short one for a narrow window.
        let notice = self.rate_limited_until.filter(|u| *u > now).map(|until| {
            let min = ((until - now) / 60).max(1).to_string();
            let full = fmt(tl!("GitHub's hourly limit was reached; full details return in {min} min"), &[("min", &min)]);
            let short = fmt(tl!("GitHub limit hit; back in {min} min"), &[("min", &min)]);
            (format!("· {full}"), format!("· {short}"))
        });
        use artcraft_launcher_core::catalog::{GITHUB_URL, SOCIAL, WEBSITE_URL};
        // Every link is an icon, reading Website, GitHub, Discord, then the social accounts.
        let named =
            |name: &'static str, label: &str, url: &'static str| widgets::IconLink { name, label: label.to_string(), tip: label.to_string(), url };
        let mut links = vec![
            named("Website", tl!("Website"), WEBSITE_URL),
            named("GitHub", tl!("GitHub"), GITHUB_URL),
            widgets::IconLink {
                name: "Discord",
                label: tl!("Discord").to_string(),
                tip: tl!("Join the ArtCraft community on Discord").to_string(),
                url: self.discord_url,
            },
        ];
        links.extend(SOCIAL.iter().map(|(name, url)| widgets::IconLink {
            name,
            label: (*name).to_string(),
            tip: fmt(tl!("ArtCraft on {name}"), &[("name", name)]),
            url,
        }));
        let icon = 13.0;
        let spacing = ui.spacing().item_spacing.x;
        // The icons on the right keep their size; the status on the left gets what is left and
        // is cut short with "…", never drawn under them.
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            widgets::icon_links(ui, icon, &links);
            ui.add_space(8.0);
            ui.with_layout(egui::Layout::left_to_right(egui::Align::Center), |ui| {
                // While GitHub is rate limited, saying so matters more than when we last checked.
                let avail = ui.available_width();
                let text = |s: &str| RichText::new(s).size(12.0).color(t.warn);
                let width = |ui: &Ui, s: &str| {
                    egui::WidgetText::from(text(s)).into_galley(ui, Some(egui::TextWrapMode::Extend), f32::INFINITY, egui::TextStyle::Body).size().x
                        + spacing
                };
                // The short notice once the full one would leave the status under a third.
                let notice = notice.map(|(full, short)| {
                    let w = width(ui, &full);
                    if w <= avail * 0.7 { (full, None, w) } else { (short.clone(), Some(full), width(ui, &short)) }
                });
                let notice_w = notice.as_ref().map_or(0.0, |(_, _, w)| *w);
                widgets::hud_elided(ui, &status, t.faint, (avail - notice_w).max(avail * 0.3));
                if let Some((shown, full, _)) = notice {
                    let resp = ui.add(egui::Label::new(text(&shown)).truncate());
                    if let Some(full) = full {
                        resp.on_hover_text(full);
                    }
                }
            });
        });
    }

    // ---- grid ----------------------------------------------------------------------------

    /// Pinned apps first (user order), then installed, then the rest under a "Not installed" header.
    pub(crate) fn grid(&mut self, ui: &mut Ui, ids: &[&'static str]) {
        let pinned_n = ids.iter().take_while(|id| self.settings.is_pinned(id)).count();
        let (pinned, rest) = ids.split_at(pinned_n);
        if !pinned.is_empty() {
            let t = Tokens::get(ui.ctx());
            widgets::hud(ui, tl!("Pinned"), t.faint);
            ui.add_space(12.0);
            self.grid_block(ui, pinned);
            if !rest.is_empty() {
                ui.add_space(28.0);
            }
        }
        let installed = rest.iter().take_while(|id| self.is_installed(id)).count();
        let (top, rest) = rest.split_at(installed);
        self.grid_block(ui, top);
        if !top.is_empty() && !rest.is_empty() {
            let t = Tokens::get(ui.ctx());
            ui.add_space(28.0);
            widgets::hud(ui, tl!("Not installed"), t.faint);
            ui.add_space(12.0);
        }
        self.grid_block(ui, rest);
        ui.add_space(24.0);
    }

    fn grid_block(&mut self, ui: &mut Ui, ids: &[&'static str]) {
        if ids.is_empty() {
            return;
        }
        let width = ui.available_width();
        // Neighbouring cards share their 1 px hairline, like the site's `gap-px` grid.
        let cols = ((width / CARD_MIN_W).floor() as usize).max(1);
        let card_w = (width + (cols as f32 - 1.0)) / cols as f32;
        let rows = ids.len().div_ceil(cols);
        let height = rows as f32 * (CARD_H - 1.0) + 1.0;
        let (area, _) = ui.allocate_exact_size(vec2(width, height), Sense::hover());
        for (i, id) in ids.iter().enumerate() {
            let (row, col) = (i / cols, i % cols);
            let min = area.min + vec2(col as f32 * (card_w - 1.0), row as f32 * (CARD_H - 1.0));
            self.card(ui, id, Rect::from_min_size(min, vec2(card_w, CARD_H)));
        }
    }

    /// Draws one app card into the caller-allocated `rect`. A card whose app has a details page gets
    /// a click target over the whole rect before its own links and buttons, so those sit on top and
    /// keep their clicks. An installed card is drawn in colour; a missing one greys out until the
    /// pointer is over it.
    fn card(&mut self, ui: &mut Ui, id: &str, rect: Rect) {
        let Some(entry) = self.entry(id).cloned() else { return };
        self.pin_drop_target(ui, id, rect, ui.clip_rect(), PinDropAxis::Horizontal);
        let t = Tokens::get(ui.ctx());
        let app = entry.app;
        let hovered = ui.rect_contains_pointer(rect);
        let wipe = if self.reduce_motion { 0.0 } else { 0.3 };
        let lift = ui.ctx().animate_bool_with_time(ui.scope_id().with(("card-hover", id)), hovered, wipe);
        // An app that is not installed is drawn in greys (icon, name, version, accent), and in its
        // colours while the pointer is over its card.
        let installed = entry.status(self.platform, self.caps.manage_apps).is_installed();
        let in_colour = installed || hovered;
        // The text and accent use the theme's muted grey; the icon is a grey copy of itself.
        let app_color = if installed { rgb(app.color) } else { t.muted.lerp_to_gamma(rgb(app.color), lift) };
        // The whole card opens the app's page. Added before the card's own links and buttons, so
        // they sit on top of it and keep their clicks.
        if AppDetails::by_id(id).is_some() {
            let open = ui.interact(rect, ui.scope_id().with(("card-open", id)), Sense::click());
            open.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, true, fmt(tl!("{name} details"), &[("name", app.name)])));
            if open.on_hover_cursor(egui::CursorIcon::PointingHand).clicked() {
                self.detail = Some(id.to_string());
            }
        }
        let painter = ui.painter_at(rect.expand(16.0));
        // A faint wash in the app's colour fades in under the pointer.
        let fill = t.bg.lerp_to_gamma(app_color, 0.05 * lift);
        painter.rect(rect, CornerRadius::ZERO, fill, t.hairline(), egui::StrokeKind::Inside);
        // On hover, a 2 px rule in the app's colour wipes in from the left along the top, inside the
        // hairlines the card shares with its neighbours (the site's rule sits within its grid gaps).
        if lift > 0.0 {
            let inside = rect.shrink(1.0);
            painter.rect_filled(Rect::from_min_size(inside.min, vec2(inside.width() * lift, 2.0)), CornerRadius::ZERO, app_color);
        }

        // The top strip: the version in the app's colour, and its GitHub page.
        let status = entry.status(self.platform, self.caps.manage_apps);
        let behind = self.behind_latest(&entry);
        let version = crate::card_parts::strip_version(&entry, &status, behind.as_deref());
        let strip = Rect::from_min_size(rect.min, vec2(rect.width(), STRIP_H));
        painter.hline(strip.x_range(), strip.bottom() - 0.5, t.hairline());
        {
            let mut strip_ui = ui.new_child(
                egui::UiBuilder::new().max_rect(strip.shrink2(vec2(CARD_PAD, 0.0))).layout(egui::Layout::left_to_right(egui::Align::Center)),
            );
            if !version.is_empty() {
                let github_w = widgets::hud_galley(&strip_ui, &format!("{} ↗", tl!("GitHub")), t.muted).size().x;
                let room = (strip_ui.available_width() - github_w - 16.0).max(0.0);
                let highlight = if in_colour { t.app_ink(app) } else { t.muted };
                let spans: Vec<(&str, egui::Color32)> =
                    version.iter().map(|(text, lit)| (text.as_str(), if *lit { highlight } else { t.muted })).collect();
                let r = widgets::hud_elided_spans(&mut strip_ui, &spans, room);
                if let Some(tip) = out_of_reach_tip(self.out_of_reach(&entry)) {
                    r.on_hover_text(tip);
                }
            }
            strip_ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                ui.spacing_mut().item_spacing.x = 16.0;
                widgets::hud_link(ui, tl!("GitHub"), &app.repo_url());
            });
        }

        let inner = Rect::from_min_max(egui::pos2(rect.left() + CARD_PAD, strip.bottom() + 18.0), rect.max - vec2(CARD_PAD, CARD_PAD));
        // A detached child: the card's contents never move the next card along.
        let mut child = ui.new_child(egui::UiBuilder::new().max_rect(inner).layout(egui::Layout::top_down(egui::Align::Min)));
        child.set_clip_rect(rect.intersect(ui.clip_rect()));
        let ui = &mut child;
        ui.horizontal(|ui| {
            const ICON: f32 = 56.0;
            let [name, tagline] = [FontId::new(22.0, theme::display()), FontId::proportional(13.5)];
            const GAP: f32 = 4.0;
            // The slot is as tall as the text beside it when that is taller, so the two share a centre.
            let block = lines_height(ui, &[&name, &tagline], GAP);
            let (slot, icon_response) = ui.allocate_exact_size(vec2(ICON, block.max(ICON)), Sense::hover());
            icon_response.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Image, true, fmt(tl!("{name} icon"), &[("name", app.name)])));
            // The icon rises a little on hover, over a soft drop shadow (the site's only shadow).
            let icon_rect = Rect::from_center_size(slot.center(), vec2(ICON, ICON)).translate(vec2(0.0, -4.0 * lift));
            ui.painter().add(
                egui::epaint::Shadow { offset: [0, 6], blur: 14, spread: 0, color: Color32::from_black_alpha(71) }
                    .as_shape(icon_rect.shrink(4.0), CornerRadius::same(12)),
            );
            if let Some(icon) = crate::icons::app_image(ui.ctx(), app.id, in_colour) {
                icon.paint_at(ui, icon_rect);
            }
            ui.add_space(6.0);
            centered_lines(ui, &[&name, &tagline], GAP, |ui| {
                // The name's row is as tall as its text, not as a button.
                ui.spacing_mut().interact_size.y = 0.0;
                ui.horizontal(|ui| {
                    widgets::wordmark_in(ui, app, 22.0, in_colour);
                    kind_badge(ui, app, &t);
                });
                ui.add(egui::Label::new(RichText::new(tr_ctx(current(), app.id, app.tagline)).font(tagline.clone()).color(t.muted)).truncate());
            });
        });
        ui.add_space(14.0);
        // Installed and up to date needs no badge: the strip has the version, and the group says the rest.
        if !matches!(status, AppStatus::UpToDate | AppStatus::Installed) {
            ui.horizontal(|ui| {
                let (text, tone) = model::entry_status_text(&entry, &status, self.caps.manage_apps);
                let r = widgets::badge(ui, &text, widgets::tone_color(&t, tone));
                if let Some(f) = entry.failure() {
                    r.on_hover_text(fmt(tl!("Couldn't check for updates: {f}"), &[("f", f)]));
                }
            });
            ui.add_space(8.0);
        }
        // Until a version is known, the sentence that says why (no release yet, installed…) stays.
        if version.is_empty() {
            let line = version_line(&entry, &status);
            if !line.trim().is_empty() {
                ui.label(RichText::new(line).size(12.5).color(t.muted));
                ui.add_space(8.0);
            }
        }
        if let Some(details) = AppDetails::by_id(id) {
            crate::card_parts::blurb(ui, details.headline, t.muted, 4);
        }
        if let Some(line) = crate::card_parts::last_updated(&entry) {
            ui.add_space(6.0);
            ui.add(egui::Label::new(RichText::new(line).size(12.5).color(t.faint)).selectable(false));
        }
        ui.with_layout(egui::Layout::bottom_up(egui::Align::Min), |ui| {
            ui.horizontal(|ui| self.actions_in(ui, &entry, &status, inner.width(), Place::Card));
        });
    }

    // ---- table ---------------------------------------------------------------------------

    pub(crate) fn table(&mut self, ui: &mut Ui, ids: &[&'static str]) {
        use egui_extras::{Column, TableBuilder};
        let t = Tokens::get(ui.ctx());
        let now = self.backend.now();
        let mut sort_clicked = None;
        let (title_h, tagline_h) = ui
            .ctx()
            .fonts_mut(|f| (f.row_height(&egui::FontId::new(TITLE_SIZE, theme::display())), f.row_height(&egui::FontId::proportional(TAGLINE_SIZE))));
        // Rows are divided by hairlines across the whole table, drawn from the first cell and
        // clipped to the scroll area.
        let clip = ui.clip_rect();
        let span = ui.available_rect_before_wrap().x_range();
        let grip_w = self.grip_w(ui, ids);

        egui::Frame::new().fill(t.bg).stroke(t.hairline()).inner_margin(egui::Margin::symmetric(16, 0)).show(ui, |ui| {
            TableBuilder::new(ui)
                .striped(false)
                .vscroll(false)
                .cell_layout(egui::Layout::left_to_right(egui::Align::Center))
                .column(Column::remainder().at_least(220.0).clip(true))
                .column(Column::exact(176.0))
                .column(Column::exact(150.0))
                .column(Column::exact(132.0))
                .column(Column::exact(104.0))
                .column(Column::exact(206.0 + grip_w))
                .header(42.0, |header| self.table_header(header, &mut sort_clicked, &t, span, clip))
                .body(|body| self.table_rows(body, ids, &t, (title_h, tagline_h), now, (span, clip)));
        });
        if let Some(k) = sort_clicked {
            if self.settings.sort == k {
                self.settings.sort_descending = !self.settings.sort_descending;
            } else {
                self.settings.sort = k;
                self.settings.sort_descending = k.starts_descending();
            }
        }
    }

    /// The table's hairline under the row `ui` is drawing, across the table's full width.
    fn table_rule(ui: &Ui, t: &Tokens, span: egui::emath::Rangef, clip: egui::Rect) {
        let y = ui.max_rect().bottom() + ui.spacing().item_spacing.y / 2.0;
        ui.ctx().layer_painter(ui.layer_id()).with_clip_rect(clip).hline(span, y, t.hairline());
    }

    /// ▲ / ▼ sort indicator next to a column header.
    fn draw_sort_arrow(p: &egui::Painter, c: egui::Pos2, down: bool, color: egui::Color32) {
        let (tip_y, base_y) = if down { (c.y + 3.0, c.y - 2.0) } else { (c.y - 3.0, c.y + 2.0) };
        let pts = vec![egui::pos2(c.x - 3.5, base_y), egui::pos2(c.x + 3.5, base_y), egui::pos2(c.x, tip_y)];
        p.add(egui::Shape::convex_polygon(pts, color, Stroke::NONE));
    }

    /// Whether to draw an arrow for this column header (Some(down)), or None.
    fn header_sort_arrow(&self, k: SortKey, active: bool, hovered: bool) -> Option<bool> {
        if active {
            Some(self.settings.sort_descending)
        } else if hovered {
            Some(k.starts_descending())
        } else {
            None
        }
    }

    /// A single header cell: a sortable button (if a `SortKey` is given) or a plain label.
    fn table_header_cell(&self, ui: &mut Ui, key: Option<SortKey>, label: &str, t: &Tokens) -> Option<SortKey> {
        let Some(k) = key else {
            // A column that is not sorted still names itself.
            if !label.is_empty() {
                widgets::hud(ui, label, t.faint);
            }
            return None;
        };
        let active = k == self.settings.sort;
        let tip = if active { tl!("Click to reverse the order") } else { tl!("Click to sort by this column") };
        // Measure first so the whole header cell (label + arrow) is the target.
        let (rect, resp) = ui.allocate_exact_size(ui.available_size(), Sense::click());
        let hovered = resp.hovered();
        let color = if active || hovered { t.ink_strong } else { t.faint };
        let galley = widgets::hud_galley(ui, label, color);
        let text_pos = egui::pos2(rect.left(), rect.center().y - galley.size().y / 2.0);
        let arrow_x = text_pos.x + galley.size().x + 4.0;
        let p = ui.painter();
        p.galley(text_pos, galley, color);
        // ▲ / ▼ for the active column; a faint hint on hover.
        if let Some(down) = self.header_sort_arrow(k, active, hovered) {
            let arrow_color = if active { t.accent_ink } else { t.faint };
            Self::draw_sort_arrow(p, egui::pos2(arrow_x + 4.0, rect.center().y), down, arrow_color);
        }
        resp.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, true, label));
        if resp.on_hover_text(tip).on_hover_cursor(egui::CursorIcon::PointingHand).clicked() { Some(k) } else { None }
    }

    /// The header row: the four sortable column labels with their arrows, and the two that are
    /// plain.
    fn table_header(
        &self,
        mut header: egui_extras::TableRow<'_, '_>,
        sort_clicked: &mut Option<SortKey>,
        t: &Tokens,
        span: egui::emath::Rangef,
        clip: egui::Rect,
    ) {
        for (key, label) in [
            (Some(SortKey::Name), tl!("App")),
            (Some(SortKey::Status), tl!("Status")),
            (None, tr_ctx(current(), "column", "Version")),
            (Some(SortKey::Released), tr_ctx(current(), "column", "Released")),
            (None, tr_ctx(current(), "column", "Author")),
            (None, ""),
        ] {
            header.col(|ui| {
                if key == Some(SortKey::Name) {
                    Self::table_rule(ui, t, span, clip);
                }
                if let Some(k) = self.table_header_cell(ui, key, label, t) {
                    *sort_clicked = Some(k);
                }
            });
        }
    }

    /// The table's one row per app: the app (click to open its page), its status, the version,
    /// when it was released, who makes it, and its actions.
    fn table_rows(
        &mut self,
        mut body: egui_extras::TableBody<'_>,
        ids: &[&'static str],
        t: &Tokens,
        fonts: (f32, f32),
        now: i64,
        rule: (egui::emath::Rangef, egui::Rect),
    ) {
        let last = ids.len().saturating_sub(1);
        let grip_w = self.grip_w(body.ui_mut(), ids);
        for (i, id) in ids.iter().enumerate() {
            let Some(entry) = self.entry(id).cloned() else { continue };
            let status = entry.status(self.platform, self.caps.manage_apps);
            let row_h = self.table_row_h(body.ui_mut(), &entry, &status);
            body.row(row_h, |mut row| {
                row.col(|ui| self.table_app_cell(ui, &entry, id, i < last, t, (fonts.0, fonts.1, rule.0, rule.1)));
                row.col(|ui| self.table_status_cell(ui, &entry, &status, t));
                row.col(|ui| self.table_version_cell(ui, &entry, &status, t));
                row.col(|ui| self.table_released_cell(ui, &entry, now, t));
                row.col(|ui| {
                    ui.label(RichText::new(entry.app.publisher).color(t.muted));
                });
                // A pinned row's grip leads its actions; the other rows leave its room empty, so
                // every row's buttons stay in line.
                row.col(|ui| {
                    if self.settings.is_pinned(id) {
                        self.actions_in(ui, &entry, &status, TABLE_ACTIONS_W + grip_w, Place::Row);
                    } else {
                        ui.add_space(grip_w);
                        self.actions_in(ui, &entry, &status, TABLE_ACTIONS_W, Place::Row);
                    }
                });
            });
        }
    }

    /// The app column: the rule, a click-to-open overlay (when the app has a details page — the
    /// guard is outside), the icon, and the name + tagline block. `rule` is whether a hairline
    /// goes under this row; `(title_h, tagline_h, span, clip)` carry the name block's metrics and
    /// the table's line width for the rule.
    fn table_app_cell(
        &mut self,
        ui: &mut Ui,
        entry: &AppEntry,
        id: &'static str,
        rule: bool,
        t: &Tokens,
        meta: (f32, f32, egui::emath::Rangef, egui::Rect),
    ) {
        let (title_h, tagline_h, span, clip) = meta;
        if rule {
            Self::table_rule(ui, t, span, clip);
        }
        let row_rect = ui.max_rect();
        // Full-row target (covers the grip column too); only this target reorders in the table.
        self.pin_drop_target(ui, id, Rect::from_x_y_ranges(span, row_rect.y_range()), clip, PinDropAxis::Vertical);
        // Clicking the app's cell opens its page (the content is added after, so it wins any hit).
        if AppDetails::by_id(id).is_some() {
            let open = ui.interact(row_rect, ui.scope_id().with(("row-open", id)), Sense::click());
            open.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, true, fmt(tl!("{name} details"), &[("name", entry.app.name)])));
            if open.on_hover_cursor(egui::CursorIcon::PointingHand).clicked() {
                self.detail = Some(id.to_string());
            }
        }
        let installed = entry.status(self.platform, self.caps.manage_apps).is_installed();
        if let Some(icon) = crate::icons::app_image(ui.ctx(), entry.app.id, installed) {
            // Decorative: the wordmark beside it carries the app name.
            ui.add(icon.fit_to_exact_size(vec2(38.0, 38.0)));
        }
        ui.add_space(4.0);
        ui.vertical(|ui| {
            const GAP: f32 = 2.0;
            ui.spacing_mut().item_spacing.y = GAP;
            // Name and tagline as one block, centred on the icon.
            let block = title_h + GAP + tagline_h;
            ui.add_space(((ui.available_height() - block) / 2.0).max(0.0));
            widgets::wordmark_in(ui, entry.app, TITLE_SIZE, installed);
            ui.add(egui::Label::new(RichText::new(tr_ctx(current(), entry.app.id, entry.app.tagline)).size(TAGLINE_SIZE).color(t.muted)).truncate());
        });
    }

    /// The status column: one badge, with the check failure (if any) in its tooltip.
    fn table_status_cell(&self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, t: &Tokens) {
        // Installed is all it says: being up to date is the absence of an update.
        let (text, tone) = if *status == AppStatus::UpToDate && entry.job.is_none() && entry.paused.is_none() {
            model::status_text(&AppStatus::Installed, self.caps.manage_apps)
        } else {
            model::entry_status_text(entry, status, self.caps.manage_apps)
        };
        let r = widgets::badge(ui, &text, widgets::tone_color(t, tone));
        if let Some(f) = entry.failure() {
            r.on_hover_text(fmt(tl!("Couldn't check for updates: {f}"), &[("f", f)]));
        }
    }

    /// The version column: what is installed, with an arrow to the new one (only that in the app's
    /// colour) when an update waits, or a quiet note of the newer release for a version kept on
    /// purpose; the latest, for an app not installed yet.
    fn table_version_cell(&self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, t: &Tokens) {
        let mono = |text: String, color| RichText::new(text).family(egui::FontFamily::Monospace).color(color);
        let (first, second) = match (*status == AppStatus::UpdateAvailable).then(|| entry.installed_label().zip(entry.latest_label())).flatten() {
            Some((from, to)) => (mono(format!("{from} → "), t.ink), Some(mono(to, t.app_ink(entry.app)))),
            None => match (entry.installed_label(), entry.latest_label()) {
                (Some(installed), _) => {
                    let note =
                        self.behind_latest(entry).map(|newer| mono(format!(" · {}", fmt(tl!("latest {version}"), &[("version", &newer)])), t.faint));
                    (mono(installed, t.ink), note)
                }
                (None, Some(latest)) => (mono(latest, t.faint), None),
                (None, None) => (mono("—".into(), t.faint), None),
            },
        };
        // One label in two colours, so it reads as one piece of text ("0.4.1 → 0.5.0").
        let style = ui.style().clone();
        let mut job = egui::text::LayoutJob::default();
        for part in std::iter::once(first).chain(second) {
            part.append_to(&mut job, &style, egui::FontSelection::Default, egui::Align::Center);
        }
        let r = ui.label(job);
        if let Some(tip) = out_of_reach_tip(self.out_of_reach(entry)) {
            r.on_hover_text(tip);
        }
    }

    /// The released column: the release date, or an em dash, with "how long ago" in its tooltip.
    fn table_released_cell(&self, ui: &mut Ui, entry: &AppEntry, now: i64, t: &Tokens) {
        let when = entry.release().and_then(|r| r.published_at);
        let r = ui.label(RichText::new(when.map_or_else(|| "—".into(), date_text)).color(t.muted));
        if let Some(w) = when {
            r.on_hover_text(ago_text(w, now));
        }
    }

    // ---- actions -------------------------------------------------------------------------

    fn primary_action(&self, entry: &AppEntry, status: &AppStatus) -> Primary {
        if !self.caps.manage_apps {
            let platform = self.platform;
            let url = entry.release().zip(platform).and_then(|(r, p)| {
                let stems: Vec<&str> = entry.app.stems().collect();
                pick_asset(r, &stems, p, p.download_kinds()).map(|(a, _)| a.url.clone())
            });
            return match (status, url) {
                (AppStatus::NoRelease, _) => Primary::Unavailable(tl!("Coming soon")),
                (AppStatus::Checking, _) => Primary::Unavailable(tl!("Checking…")),
                (_, Some(url)) => Primary::Download(url),
                (_, None) => Primary::Unavailable(tl!("Not available")),
            };
        }
        // Once the pinned version is the installed one, the normal statuses (Open) take over again.
        if let Some(artcraft_launcher_core::protocol::VersionTrack::Pinned(tag)) = self.settings.versions.get(entry.app.id)
            && entry.installed.as_ref().and_then(|i| i.version.as_ref()) != artcraft_launcher_core::version::parse(tag).as_ref()
        {
            // Checked by the backend, and an install of it would go ahead here.
            let checked = self.version_installs(entry, tag) == Some(true)
                && !matches!(status, AppStatus::Checking | AppStatus::NoRelease | AppStatus::Unavailable);
            return Primary::SelectedVersion { tag: tag.clone(), checked };
        }
        match status {
            AppStatus::Available if entry.ready => Primary::Retry(tl!("Retry install").into(), vec![tl!("Install")]),
            AppStatus::UpdateAvailable if entry.ready => Primary::Retry(
                fmt(tl!("Retry update to {version}"), &[("version", &entry.latest_label().unwrap_or_default())]),
                vec![tl!("Retry update"), tl!("Update")],
            ),
            AppStatus::Available => Primary::Install,
            AppStatus::UpdateAvailable => Primary::Update(entry.latest_label().unwrap_or_default()),
            AppStatus::UpToDate | AppStatus::Installed => Primary::Open,
            AppStatus::Checking => Primary::Unavailable(tl!("Checking…")),
            AppStatus::NoRelease => Primary::Unavailable(tl!("Coming soon")),
            AppStatus::Unavailable => Primary::Unavailable(if entry.failure().is_some() { tl!("Offline") } else { tl!("Not available") }),
        }
    }

    /// A table row's height: taller where its update's Open and Update stack because they don't
    /// fit side by side (a language with long words). Mirrors [`Self::actions_in`]: a running or
    /// paused download shows its own controls instead.
    fn table_row_h(&self, ui: &Ui, entry: &AppEntry, status: &AppStatus) -> f32 {
        let busy = entry.job.is_some() || (entry.paused.is_some() && self.caps.manage_apps);
        let stacked = !busy
            && UpdateLabels::of(self.primary_action(entry, status)).zip(open_labels(entry, status)).is_some_and(|(update, (open, _))| {
                matches!(update_split(ui, Place::Row, main_width(ui, TABLE_ACTIONS_W), &open, &update), Some(widgets::Split::Stacked { .. }))
            });
        // The same space above and below as a row's single button has, halved.
        if stacked { widgets::STACKED_H + (TABLE_ROW_H - theme::CONTROL_H) / 2.0 } else { TABLE_ROW_H }
    }

    /// The main button and the `⋯` menu beside it, within `width`, as `place` has them. On the
    /// details page the website, GitHub and releases links are buttons of its own, not menu rows.
    /// In the grid and the table, a pinned app's actions start with the handle that reorders it,
    /// which takes one square of `width` (the table widens its column by [`Self::grip_w`] for it).
    pub(crate) fn actions_in(&mut self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, mut width: f32, place: Place) {
        let id = entry.app.id.to_string();
        let gap = ui.spacing().item_spacing.x;
        let links_in_menu = place.links_in_menu();
        if links_in_menu && self.settings.is_pinned(entry.app.id) {
            self.pin_grip(ui, entry);
            width -= theme::CONTROL_H + gap;
        }
        // One square button (the menu) beside the main one.
        let main_w = main_width(ui, width);
        if entry.job.is_some() {
            self.job_actions(ui, entry, &id, main_w, width);
            return;
        }
        if self.paused_actions(ui, entry, &id, status, width, links_in_menu) {
            return;
        }
        self.primary_button(ui, entry, &id, status, main_w, place);
        self.menu(ui, entry, status, links_in_menu);
    }

    /// The room a pin grip takes: one square and a gap while the list shows a pinned app (they come
    /// first), else none.
    fn grip_w(&self, ui: &Ui, ids: &[&'static str]) -> f32 {
        if ids.first().is_some_and(|id| self.settings.is_pinned(id)) { theme::CONTROL_H + ui.spacing().item_spacing.x } else { 0.0 }
    }

    /// Cancel an in-progress pin reorder (Escape), restoring the pinned order from drag start
    /// (live hover already mutated `settings.pinned`). Called from [`Self::ui`] before the
    /// empty-results branch so Escape still works when search/filter hides every app mid-drag.
    pub(crate) fn clear_pin_drag_on_escape(&mut self, ui: &Ui) {
        if self.pin_dragging.is_some()
            && ui.input(|i| i.key_pressed(egui::Key::Escape))
            && let Some((_, original)) = self.pin_dragging.take()
        {
            self.settings.pinned = original;
        }
    }

    /// Drag handle that reorders this pinned app among the other pinned apps.
    fn pin_grip(&mut self, ui: &mut Ui, entry: &AppEntry) {
        let tip = fmt(tl!("Reorder {name}"), &[("name", entry.app.name)]);
        let resp = widgets::grip_button(ui, &tip);
        // Only latch on drag start: after a reorder, the same egui widget id can sit on a
        // different app's row, and `dragged()` would steal `pin_dragging` mid-gesture.
        // Do not clear on `drag_stopped` here — drop targets must see the release first;
        // `LauncherUi::ui` clears `pin_dragging` after the list once the pointer is up.
        if resp.drag_started() {
            self.pin_dragging = Some((entry.app.id.to_string(), self.settings.pinned.clone()));
        }
    }

    /// While a pin handle is dragged, hovering another pinned card/row moves the dragged app there.
    /// Grid uses the horizontal half; table uses the vertical half. One target per surface — the
    /// table's full-row target already covers the grip column, so the grip itself does not reorder.
    /// A release over a target still counts: `LauncherUi::ui` ends the drag after the list.
    fn pin_drop_target(&mut self, ui: &Ui, id: &str, rect: Rect, viewport: Rect, axis: PinDropAxis) {
        let Some((from, _)) = self.pin_dragging.as_ref() else {
            return;
        };
        let from = from.clone();
        if from == id || !self.settings.is_pinned(id) {
            return;
        }
        let Some(pos) = ui.input(|i| i.pointer.interact_pos()) else {
            return;
        };
        // Layout includes clipped-off entries. Only the scroll viewport accepts drops; the
        // table passes its full viewport rather than the narrower first-column clip.
        if !rect.contains(pos) || !viewport.contains(pos) {
            return;
        }
        let Some(to_i) = self.settings.pinned.iter().position(|p| p == id) else {
            return;
        };
        let insert_before = match axis {
            PinDropAxis::Horizontal => pos.x < rect.center().x,
            PinDropAxis::Vertical => pos.y < rect.center().y,
        };
        let insertion_index = if insert_before { to_i } else { to_i.saturating_add(1) };
        self.settings.reorder_pinned_to(&from, insertion_index);
    }

    /// A running job's row: one progress bar, with pause and cancel while its download is under
    /// way, or only a cancel while the job waits for another app's installer.
    fn job_actions(&mut self, ui: &mut Ui, entry: &AppEntry, id: &str, main_w: f32, width: f32) {
        let t = Tokens::get(ui.ctx());
        let gap = ui.spacing().item_spacing.x;
        let Some(phase) = entry.job else { return };
        // Two square buttons (pause, cancel) beside the bar while downloading.
        let bar_w = (width - 2.0 * (theme::CONTROL_H + gap) - 4.0).max(100.0);
        let short = bar_w < 200.0;
        let amount = |done: u64, total: u64| {
            if total > 0 {
                fmt(tl!("{done} of {total}"), &[("done", &widgets::human_bytes(done)), ("total", &widgets::human_bytes(total))])
            } else {
                widgets::human_bytes(done)
            }
        };
        let (fraction, caption, color) = match phase {
            JobPhase::Downloading { done, total } => {
                let f = (total > 0).then(|| done as f32 / total as f32);
                let pct = f.map(|f| format!(" · {:.0}%", f * 100.0)).unwrap_or_default();
                let caption = if bar_w < 150.0 {
                    match f {
                        Some(f) => fmt(tl!("{done} of {total}"), &[("done", &format!("{:.0}%", f * 100.0)), ("total", &widgets::human_bytes(total))]),
                        None => widgets::human_bytes(done),
                    }
                } else if short {
                    format!("{}{pct}", amount(done, total))
                } else {
                    format!("{} {}{pct}", tl!("Downloading"), amount(done, total))
                };
                (f, caption, rgb(entry.app.color))
            }
            JobPhase::Reconnecting { done, total } => {
                let f = (total > 0).then(|| done as f32 / total as f32);
                (f, if short { tl!("Reconnecting…").into() } else { format!("{} {}", tl!("Reconnecting…"), amount(done, total)) }, t.warn)
            }
            JobPhase::Verifying => (None, tl!("Verifying checksum…").into(), rgb(entry.app.color)),
            JobPhase::Waiting => (None, tl!("Waiting for another app…").into(), rgb(entry.app.color)),
            JobPhase::Installing => (None, tl!("Installing…").into(), rgb(entry.app.color)),
            JobPhase::Removing => (None, tl!("Removing…").into(), rgb(entry.app.color)),
        };
        let downloading = matches!(phase, JobPhase::Downloading { .. } | JobPhase::Reconnecting { .. });
        // A job waiting for the installer hasn't started it yet, so it can still be called off.
        let waiting = phase == JobPhase::Waiting;
        // Waiting has one square button beside the bar, like the menu otherwise.
        widgets::progress(ui, fraction, &caption, color, if downloading { bar_w } else { main_w });
        if downloading && widgets::glyph_button(ui, widgets::Glyph::Pause, tl!("Pause download")).clicked() {
            self.act_command(Command::Pause { app: id.to_string() });
        }
        if (downloading || waiting)
            && widgets::glyph_button(ui, widgets::Glyph::Close, if waiting { tl!("Cancel") } else { tl!("Cancel download") }).clicked()
        {
            self.act_command(Command::Cancel { app: id.to_string() });
        }
    }

    /// A paused download's row (where the launcher manages installs here): resume, then discard
    /// and the `⋯` menu — two squares and a main button. Returns `false` otherwise, so the main
    /// button shows instead.
    fn paused_actions(&mut self, ui: &mut Ui, entry: &AppEntry, id: &str, status: &AppStatus, width: f32, links_in_menu: bool) -> bool {
        let gap = ui.spacing().item_spacing.x;
        let Some(p) = entry.paused else { return false };
        if !self.caps.manage_apps {
            return false;
        }
        let pct = if p.total > 0 { format!(" · {:.0}%", p.done as f32 / p.total as f32 * 100.0) } else { String::new() };
        // Resume, then discard and the menu (two squares).
        let resume_w = (width - 2.0 * (theme::CONTROL_H + gap)).max(90.0);
        // Narrow (the table): just tl!("Resume"); the tooltip says how far it got.
        let label = match resume_w {
            w if w < 150.0 => tl!("Resume").to_string(),
            w if w < 220.0 => format!("{}{pct}", tl!("Resume")),
            _ => format!("{}{pct}", tl!("Resume download")),
        };
        let resp = widgets::button(ui, &label, Kind::Primary, resume_w);
        let tip = if p.total > 0 {
            fmt(tl!("{done} of {total} downloaded"), &[("done", &widgets::human_bytes(p.done)), ("total", &widgets::human_bytes(p.total))])
        } else {
            fmt(tl!("{done} downloaded"), &[("done", &widgets::human_bytes(p.done))])
        };
        if resp.on_hover_text(tip).clicked() {
            self.install_app(id);
        }
        if widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Discard download")).clicked() {
            self.act_command(Command::Cancel { app: id.to_string() });
        }
        self.menu(ui, entry, status, links_in_menu);
        true
    }

    /// What the main button does: open, install/update, retry, plain download, or nothing.
    fn primary_button(&mut self, ui: &mut Ui, entry: &AppEntry, id: &str, status: &AppStatus, main_w: f32, place: Place) {
        match self.primary_action(entry, status) {
            Primary::Install => {
                if widgets::button(ui, tl!("Install"), Kind::Primary, main_w).clicked() {
                    self.install_app(id);
                }
            }
            update @ (Primary::Retry(..) | Primary::Update(_)) => {
                if let Some(labels) = UpdateLabels::of(update) {
                    self.update_button(ui, entry, status, &labels, main_w, place);
                }
            }
            Primary::SelectedVersion { tag, checked } => {
                let label = fmt(tl!("Install version {version}"), &[("version", &tag)]);
                let resp = ui.add_enabled_ui(checked, |ui| widgets::button(ui, &label, Kind::Primary, main_w)).inner;
                let resp = match self.version_refusal(entry, &tag) {
                    Some(why) => resp.on_disabled_hover_text(why),
                    None => resp,
                };
                if resp.clicked() {
                    self.install_app(id);
                }
            }
            Primary::Open => {
                if widgets::button(ui, tl!("Open"), Kind::Secondary, main_w).clicked() {
                    self.launch_app(id);
                }
            }
            Primary::Download(url) => {
                let label = match self.platform {
                    Some(p) => fmt(tl!("Download for {os}"), &[("os", p.os.label())]),
                    None => tl!("Download").into(),
                };
                if widgets::button(ui, &label, Kind::Primary, main_w).clicked() {
                    widgets::open_external_link(ui.ctx(), &url);
                }
            }
            Primary::Unavailable(label) => {
                ui.add_enabled_ui(false, |ui| widgets::button(ui, label, Kind::Secondary, main_w));
            }
        }
    }

    /// The button that installs an update (`update`). While the update waits, an installed copy
    /// can still be opened as it is: an Open half, naming its version where there's room, sits
    /// before the update half, or above it in a table row too narrow for both side by side. Where
    /// they don't fit at all, the update button shows alone and Open stays in the `⋯` menu.
    fn update_button(&mut self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, update: &UpdateLabels, main_w: f32, place: Place) {
        let id = entry.app.id;
        // Check if this update version was forgotten by the user
        let forgotten_version = entry.forgotten_update_version(&self.settings);
        let show_forget = forgotten_version.is_none();

        if let Some((open, about)) = open_labels(entry, status)
            && let Some(split) = update_split(ui, place, main_w, &open, update)
        {
            let (open, install) = widgets::split_button(
                ui,
                widgets::Half { label: &about, kind: Kind::Secondary },
                widgets::Half { label: &update.label, kind: Kind::Primary },
                split,
            );
            if open.on_hover_text(&about).clicked() {
                self.launch_app(id);
            }
            let install = match update.tip {
                Some(tip) => install.on_hover_text(tip),
                None => install,
            };
            if install.clicked() {
                self.install_app(id);
            }
            // Add forget button next to the split button when there's room
            if show_forget {
                if widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Forget this update"))
                    .on_hover_text(tl!("Stop showing this update version"))
                    .clicked()
                {
                    if let Some(version) = entry.latest_label() {
                        self.settings.forget_update(id, &version);
                    }
                }
            }
            return;
        }
        // Shortened to fit, it is still read out in full.
        let resp = widgets::labelled_button(ui, fitted(ui, &update.label, &update.shorter, main_w), &update.label, Kind::Primary, main_w);
        let resp = match update.tip {
            Some(tip) => resp.on_hover_text(tip),
            None => resp,
        };
        if resp.clicked() {
            self.install_app(id);
        }
        // Add forget button next to the update button when there's room
        if show_forget {
            if widgets::glyph_button(ui, widgets::Glyph::Close, tl!("Forget this update"))
                .on_hover_text(tl!("Stop showing this update version"))
                .clicked()
            {
                if let Some(version) = entry.latest_label() {
                    self.settings.forget_update(id, &version);
                }
            }
        }
    }

    /// The card's "…" menu. Backend commands are queued at the action boundary; dialog, settings and
    /// external-link actions happen inline. "Download again" appears
    /// only for a kept download in a ready available/update state and cancels before installing;
    /// `links` adds the website/repository/releases rows, which the details drawer omits because it
    /// shows them as buttons.
    fn menu(&mut self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, links: bool) {
        let id = entry.app.id.to_string();
        let manage = self.caps.manage_apps;
        let reveal = self.caps.reveal_label;
        widgets::more_menu(ui, entry.app.name, |ui| {
            if ui.button(tl!("Choose version")).clicked() {
                self.open_versions(&id);
                ui.close();
            }
            if entry.release().is_some() && ui.button(tl!("Release notes")).clicked() {
                self.dialog = Some(Dialog::Notes(id.clone()));
                ui.close();
            }
            // Only where Install would download: an up-to-date app would be reinstalled.
            let can_download_again =
                manage && entry.ready && entry.paused.is_none() && matches!(status, AppStatus::Available | AppStatus::UpdateAvailable);
            if can_download_again && ui.button(tl!("Download again")).clicked() {
                self.act_command(Command::Cancel { app: id.clone() });
                self.install_app(&id);
                ui.close();
            }
            if manage && status.is_installed() {
                self.menu_installed(ui, entry, status, reveal);
            }
            if !manage {
                self.menu_downloads(ui, entry);
            }
            // The drawer shows the links as buttons, so its menu leaves them out (but keeps Hide).
            if links {
                ui.separator();
                let link = |ui: &mut Ui, label: &str, url: String| {
                    if ui.button(label).clicked() {
                        widgets::open_external_link(ui.ctx(), &url);
                        ui.close();
                    }
                };
                link(ui, tl!("Website"), entry.app.website());
                link(ui, tl!("GitHub repository"), entry.app.repo_url());
                link(ui, tl!("All releases"), entry.app.releases_url());
            }
            self.menu_pin(ui, entry, &id);
            self.menu_hide(ui, entry, &id);
        });
    }

    /// Pin — or unpin — the app at the top of the list. Hidden apps are not offered Pin to top
    /// (they can still Unpin if somehow still pinned). Move up/down reorder for keyboard users.
    fn menu_pin(&mut self, ui: &mut Ui, entry: &AppEntry, id: &str) {
        ui.separator();
        let pinned = self.settings.is_pinned(entry.app.id);
        let hidden = self.settings.hidden.contains(entry.app.id);
        if pinned {
            if ui.button(tl!("Unpin")).clicked() {
                self.settings.unpin_app(id);
                ui.close();
            }
            // Neighbors must be on screen under the current search/filter — catalog presence alone
            // would let Move skip over a filtered pin with no visible change.
            let visible: std::collections::HashSet<&str> = self.visible_ids().into_iter().collect();
            let known = |pid: &str| visible.contains(pid);
            // Up: into the slot before the neighbour above; down: into the slot after the one below.
            let up = self.settings.pinned_neighbor(id, -1, known);
            let down = self.settings.pinned_neighbor(id, 1, known).map(|j| j + 1);
            for (slot, label) in [(up, tl!("Move up")), (down, tl!("Move down"))] {
                if let Some(slot) = slot
                    && ui.button(label).clicked()
                {
                    self.settings.reorder_pinned_to(id, slot);
                    ui.close();
                }
            }
        } else if !hidden && ui.button(tl!("Pin to top")).clicked() {
            self.settings.pin_app(id);
            ui.close();
        }
    }

    /// The menu items for an installed app: open, reveal in the file manager,
    /// reinstall (where an install would go ahead), and uninstall (which asks first).
    fn menu_installed(&mut self, ui: &mut Ui, entry: &AppEntry, status: &AppStatus, reveal: &'static str) {
        let id = entry.app.id;
        if ui.button(tl!("Open")).clicked() {
            self.launch_app(id);
            ui.close();
        }
        if ui.button(t(reveal)).clicked() {
            self.act_command(Command::Reveal { app: id.to_string() });
            ui.close();
        }
        if *status == AppStatus::UpToDate && entry.installs_here(self.platform) && ui.button(tl!("Reinstall")).clicked() {
            self.install_app(id);
            ui.close();
        }
        ui.separator();
        if ui.button(RichText::new(tl!("Uninstall…")).color(Tokens::get(ui.ctx()).bad)).clicked() {
            self.dialog = Some(Dialog::ConfirmUninstall(id.to_string()));
            ui.close();
        }
    }

    /// Where the system manages installs: a plain-download item per format this platform can
    /// have that the app publishes. Nothing shows when the app has nothing this platform wants.
    fn menu_downloads(&self, ui: &mut Ui, entry: &AppEntry) {
        let Some(r) = entry.release() else { return };
        let Some(p) = self.platform else { return };
        let stems: Vec<&str> = entry.app.stems().collect();
        let options: Vec<(String, String)> = p
            .download_kinds()
            .iter()
            .filter_map(|k| {
                pick_asset(r, &stems, p, &[*k])
                    .filter(|(a, _)| a.size > 0)
                    .map(|(a, _)| (format!("{} · {}", crate::i18n::t(k.label()), widgets::human_bytes(a.size)), a.url.clone()))
            })
            .collect();
        if !options.is_empty() {
            ui.separator();
            for (label, url) in options {
                if ui.button(label).clicked() {
                    widgets::open_external_link(ui.ctx(), &url);
                    ui.close();
                }
            }
        }
    }

    /// Hide — or unhide — the app, keeping the Hidden filter sane when the hidden set empties.
    /// Hiding also clears a pin so a hidden app cannot float back into the main list.
    fn menu_hide(&mut self, ui: &mut Ui, entry: &AppEntry, id: &str) {
        ui.separator();
        let hidden = self.settings.hidden.contains(entry.app.id);
        if ui.button(if hidden { tl!("Unhide App") } else { tl!("Hide App") }).clicked() {
            if hidden {
                self.settings.hidden.remove(entry.app.id);
                if self.settings.hidden.is_empty() && self.settings.filter == Filter::Hidden {
                    self.settings.filter = Filter::All;
                }
            } else {
                self.settings.unpin_app(id);
                self.settings.hidden.insert(id.to_string());
            }
            ui.close();
        }
    }
}

/// Which half of a pin drop target decides insert-before vs insert-after.
#[derive(Clone, Copy, Debug)]
enum PinDropAxis {
    /// Grid cards: left/right of the card.
    Horizontal,
    /// Table rows: above/below the row midline.
    Vertical,
}

/// What the grid's sort dropdown offers: the order and, for names, which way. The installed apps
/// always sit above the rest.
const GRID_SORTS: [(SortKey, bool); 4] = [(SortKey::Name, false), (SortKey::Name, true), (SortKey::Released, true), (SortKey::Frequent, true)];

/// Which of [`GRID_SORTS`] the settings come to. Anything else (the old suite order, a table
/// column) reads as Name, A to Z.
pub(crate) fn grid_sort_now(s: &crate::settings::Settings) -> (SortKey, bool) {
    match s.sort {
        SortKey::Name => (SortKey::Name, s.sort_descending),
        SortKey::Released => (SortKey::Released, true),
        SortKey::Frequent => (SortKey::Frequent, true),
        _ => (SortKey::Name, false),
    }
}

fn grid_sort_label((key, descending): (SortKey, bool)) -> &'static str {
    match (key, descending) {
        (SortKey::Released, _) => tl!("Recently updated"),
        (SortKey::Frequent, _) => tl!("Frequently used"),
        (_, true) => tl!("Name (Z–A)"),
        _ => tl!("Name (A–Z)"),
    }
}

/// "0.4.1 installed → 0.5.0 released · Oct 8, 2026" and friends.
pub(crate) fn version_line(e: &AppEntry, status: &AppStatus) -> String {
    let released = e.release().and_then(|r| r.published_at).map(|at| format!(" · {}", date_text(at))).unwrap_or_default();
    let inst_ver = e.installed.as_ref().and_then(|i| i.version.as_ref().map(ToString::to_string));
    let latest = e.latest_label();
    match (status, inst_ver.as_deref(), latest.as_deref()) {
        (AppStatus::UpdateAvailable, Some(i), Some(l)) => {
            format!("{}{released}", fmt(tl!("{version} installed → {latest} released"), &[("version", i), ("latest", l)]))
        }
        (AppStatus::UpToDate, Some(i), _) => format!("{}{released}", fmt(tl!("Version {version}"), &[("version", i)])),
        (_, Some(i), Some(l)) => fmt(tl!("{installed} installed · latest {latest}"), &[("installed", i), ("latest", l)]),
        (_, None, Some(l)) if e.installed.is_some() => fmt(tl!("Installed · latest {latest}"), &[("latest", l)]),
        (_, Some(i), None) => fmt(tl!("Version {version} installed"), &[("version", i)]),
        (_, None, None) if e.installed.is_some() => tl!("Installed").to_string(),
        (_, None, Some(l)) => format!("{}{released}", fmt(tl!("Version {latest}"), &[("latest", l)])),
        (AppStatus::NoRelease, None, None) => tl!("No release published yet").to_string(),
        _ => " ".to_string(),
    }
}

/// The launcher's own download for this platform. `flatpak` is whether this copy runs as a
/// Flatpak; such a copy's download stays the `.flatpak` bundle — offering it an AppImage (or a
/// `.deb`) would point at replacing the sandboxed install with a different one.
pub(crate) fn launcher_download(r: &artcraft_launcher_core::Release, p: artcraft_launcher_core::Platform, flatpak: bool) -> Option<String> {
    launcher_asset(r, p, flatpak).map(|a| a.url.clone())
}

/// The asset behind [`launcher_download`].
pub(crate) fn launcher_asset(
    r: &artcraft_launcher_core::Release,
    p: artcraft_launcher_core::Platform,
    flatpak: bool,
) -> Option<&artcraft_launcher_core::release::Asset> {
    use artcraft_launcher_core::PackageKind;
    let kinds: &[PackageKind] = match p.os {
        artcraft_launcher_core::Os::Linux if flatpak => &[PackageKind::Flatpak],
        artcraft_launcher_core::Os::Linux => &[PackageKind::AppImage, PackageKind::Deb],
        _ => p.default_kinds(),
    };
    pick_asset(r, &[artcraft_launcher_core::catalog::LAUNCHER_ID], p, kinds).map(|(a, _)| a)
}

/// A column of single-line texts, one per font and `gap` apart, centred across the row it is in.
/// `ui.vertical` starts at the top of the row instead: a row only centres what it knows the height of.
/// Each line is measured as an empty galley, which is rounded to the pixel like a label, unlike `Fonts::row_height`.
fn centered_lines(ui: &mut Ui, fonts: &[&FontId], gap: f32, add_contents: impl FnOnce(&mut Ui)) {
    let height = lines_height(ui, fonts, gap);
    ui.allocate_ui_with_layout(vec2(ui.available_width(), height), egui::Layout::top_down(egui::Align::Min), |ui| {
        ui.spacing_mut().item_spacing.y = gap;
        add_contents(ui);
    });
}

/// The height of [`centered_lines`] with these fonts.
fn lines_height(ui: &Ui, fonts: &[&FontId], gap: f32) -> f32 {
    let line = |font: &FontId| ui.fonts_mut(|f| f.layout_no_wrap(String::new(), font.clone(), Color32::PLACEHOLDER)).size().y;
    (fonts.iter().map(|font| line(font) + gap).sum::<f32>() - gap).max(0.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use artcraft_launcher_core::catalog::LAUNCHER_ID;
    use artcraft_launcher_core::{Arch, Asset, Platform, Release};

    fn release() -> Release {
        let asset = |name: &str| Asset { name: name.into(), size: 0, url: format!("https://dl.example/{name}"), sha256: None };
        Release {
            tag: "v0.4.1".into(),
            version: None,
            name: "ArtCraft Launcher v0.4.1".into(),
            published_at: None,
            html_url: "https://github.com/storytold/craft-launcher/releases/tag/v0.4.1".into(),
            notes: String::new(),
            prerelease: false,
            assets: vec![
                asset(&format!("{LAUNCHER_ID}-0.4.1-linux-x86_64.flatpak")),
                asset(&format!("{LAUNCHER_ID}-0.4.1-linux-x86_64.AppImage")),
                asset(&format!("{LAUNCHER_ID}-0.4.1-linux-x86_64.deb")),
            ],
        }
    }

    fn platform() -> Platform {
        Platform { os: artcraft_launcher_core::Os::Linux, arch: Arch::X64 }
    }

    #[test]
    fn a_flatpak_copy_of_the_launcher_gets_the_bundle() {
        let url = launcher_download(&release(), platform(), true).unwrap();
        assert_eq!(url, format!("https://dl.example/{LAUNCHER_ID}-0.4.1-linux-x86_64.flatpak"));
    }

    #[test]
    fn a_plain_linux_copy_still_gets_the_appimage() {
        let url = launcher_download(&release(), platform(), false).unwrap();
        assert_eq!(url, format!("https://dl.example/{LAUNCHER_ID}-0.4.1-linux-x86_64.AppImage"));
    }
}
