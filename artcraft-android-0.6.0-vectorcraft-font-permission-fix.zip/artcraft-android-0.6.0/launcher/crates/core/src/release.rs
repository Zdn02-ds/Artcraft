//! GitHub releases: reading the API's answer and `SHA256SUMS.txt`.
//!
//! Everything here is untrusted input. Sizes are bounded by the caller, download links must point
//! at the app's own release downloads, and checksums must look like checksums.

use serde::{Deserialize, Serialize};

use crate::version::{self, Version};

/// One downloadable file of a release.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Asset {
    pub name: String,
    /// Bytes; 0 when unknown.
    pub size: u64,
    /// `https://github.com/<repo>/releases/download/<tag>/<name>`.
    pub url: String,
    /// Lowercase hex SHA-256, when GitHub or `SHA256SUMS.txt` told us.
    pub sha256: Option<String>,
}

/// A published release of one app.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Release {
    pub tag: String,
    pub version: Option<Version>,
    /// `PhotoCraft v0.5.0`
    pub name: String,
    /// Unix seconds; `None` when only the tag is known.
    pub published_at: Option<i64>,
    pub html_url: String,
    /// Release notes (Markdown), capped.
    pub notes: String,
    pub prerelease: bool,
    pub assets: Vec<Asset>,
}

impl Release {
    pub fn version_label(&self) -> String {
        self.version.as_ref().map_or_else(|| self.tag.clone(), ToString::to_string)
    }

    /// Fills in checksums from a `SHA256SUMS.txt` for assets that don't have one.
    pub fn apply_sums(&mut self, sums: &[(String, String)]) {
        for asset in &mut self.assets {
            if asset.sha256.is_none() {
                asset.sha256 = sums.iter().find(|(_, n)| *n == asset.name).map(|(h, _)| h.clone());
            }
        }
    }

    pub fn sums_asset(&self) -> Option<&Asset> {
        self.assets.iter().find(|a| a.name == "SHA256SUMS.txt")
    }
}

const MAX_NOTES: usize = 64 * 1024;

fn is_hex64(s: &str) -> bool {
    s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit())
}

/// Whether `url` is safe to hand to the system browser from untrusted text (release notes):
/// `https` only, a host, no user-info, no spaces or control characters, and no shell metacharacters.
///
/// The system opener is not always a direct `open`: the pinned `webbrowser` crate's WSL fallback
/// passes the URL to `cmd.exe /c start` while escaping only `^` and `&`, so a character like `|`
/// in an otherwise valid URL becomes a command separator (CWE-78). Because a legitimate
/// `https://` web link never needs these characters unescaped, we refuse any URL that contains a
/// shell/cmd metacharacter rather than rely on the opener to neutralise it.
pub fn safe_web_link(url: &str) -> bool {
    let Some(rest) = url.strip_prefix("https://") else { return false };
    let authority = rest.split(['/', '?', '#']).next().unwrap_or_default();
    url.len() <= 2000
        && !authority.is_empty()
        && !authority.contains(['@', '\\'])
        && !url.chars().any(|c| c.is_control() || c.is_whitespace())
        && !url.chars().any(is_shell_meta)
}

/// Characters a command interpreter (POSIX shells or `cmd.exe`) may treat specially. A real
/// `https` URL never needs any of them unescaped in a browser-opened link. `%` matters because
/// `cmd.exe` expands `%NAME%` references, and an expanded value could itself carry metacharacters.
pub fn is_shell_meta(c: char) -> bool {
    matches!(c, '|' | '&' | ';' | '<' | '>' | '(' | ')' | '$' | '`' | '"' | '\'' | '^' | '!' | '*' | '%' | '{' | '}' | '[' | ']')
}

/// Whether `url` is a valid release page URL strictly for `repo` on GitHub:
/// starts with `https://github.com/<repo>/releases`, contains no dot-segments (`.` or `..`),
/// no percent-encoded path separators (`%2f`, `%5c`), no query/fragment/backslash, and
/// satisfies [`safe_web_link`] (no shell metacharacters or control bytes, CWE-78).
pub fn safe_release_html_url(repo: &str, url: &str) -> Option<String> {
    if !safe_web_link(url) {
        return None;
    }
    let releases = format!("https://github.com/{repo}/releases");
    if url == releases {
        return Some(url.to_string());
    }
    let rest = url.strip_prefix(&releases)?;
    let path = rest.strip_prefix('/')?;
    if path.is_empty() || path.contains(['?', '#', '\\']) {
        return None;
    }
    for seg in path.split('/') {
        if seg.is_empty() || seg == "." || seg == ".." || seg.contains("%2f") || seg.contains("%2F") || seg.contains("%5c") || seg.contains("%5C") {
            return None;
        }
    }
    Some(url.to_string())
}

/// The prefix every download of `repo` must start with.
pub fn download_prefix(repo: &str) -> String {
    format!("https://github.com/{repo}/releases/download/")
}

/// Whether `url` is a download that truly belongs to `repo`.
///
/// A raw `starts_with(prefix)` check is not enough: a value such as
/// `https://github.com/storytold/craft-launcher/releases/download/../../../ATTACKER/REPO/releases/download/v1/x`
/// shares the prefix textually, yet its interpreted path escapes the repository. The link is
/// accepted only when the text after the prefix is exactly `<tag>/<name>` — two non-empty path
/// segments with no traversal (`.`/`..`), no additional slashes, no query or fragment, and no
/// backslash or percent-encoded separators that a client could later re-interpret.
pub fn download_url_under(url: &str, prefix: &str) -> bool {
    let Some(rest) = url.strip_prefix(prefix) else { return false };
    download_suffix_ok(rest)
}

/// Whether `url` sits under a developer mirror `base` (ending in `/`) without escaping it.
pub fn download_url_under_mirror(url: &str, base: &str) -> bool {
    let Some(rest) = url.strip_prefix(base) else { return false };
    // A mirror serves `<tag>/<name>` just like GitHub, but we only require that it can't climb out
    // of its own folder; its layout is otherwise the developer's business.
    !rest.is_empty() && !url.contains(['?', '#', '\\']) && !contains_traversal(rest) && !contains_encoded_separator(rest)
}

/// `<tag>/<name>`: exactly two non-empty segments, no traversal, no re-interpretable separators.
fn download_suffix_ok(rest: &str) -> bool {
    if rest.contains(['?', '#', '\\']) || contains_encoded_separator(rest) {
        return false;
    }
    let mut parts = rest.split('/');
    let (Some(tag), Some(name), None) = (parts.next(), parts.next(), parts.next()) else { return false };
    valid_tag(tag) && valid_file_name(name)
}

/// Any `.` or `..` path segment that could climb out of the repository.
fn contains_traversal(rest: &str) -> bool {
    rest.split('/').any(|seg| seg == "." || seg == "..")
}

/// Percent-encoded slash or backslash (`%2f`, `%5c`): a client could decode these back into
/// separators after the check, so a confined URL must not contain them.
fn contains_encoded_separator(rest: &str) -> bool {
    let bytes = rest.as_bytes();
    bytes.windows(3).any(|w| w[0] == b'%' && matches!(&w[1..].to_ascii_lowercase()[..], b"2f" | b"5c"))
}

/// Reads `GET /repos/<repo>/releases/latest` (or one element of `/releases`).
pub fn parse_github_release(json: &str, repo: &str) -> Result<Release, String> {
    let v: serde_json::Value = serde_json::from_str(json).map_err(|e| format!("unreadable answer from GitHub ({e})"))?;
    release_from_value(&v, repo)
}

/// Published releases offered for manual selection, in GitHub's order.
/// Drafts and unparseable tags cannot be installed.
pub fn parse_github_versions(json: &str, repo: &str) -> Result<Vec<Release>, String> {
    let v: serde_json::Value = serde_json::from_str(json).map_err(|e| format!("unreadable answer from GitHub ({e})"))?;
    let list = v.as_array().ok_or("unexpected answer from GitHub")?;
    Ok(list
        .iter()
        .filter(|item| !item["draft"].as_bool().unwrap_or(false))
        .filter_map(|item| release_from_value(item, repo).ok())
        .filter(|r| r.version.is_some())
        .take(100)
        .collect())
}

/// A published, explicitly marked nightly build, not merely a beta or release candidate.
pub fn is_nightly(release: &Release) -> bool {
    release.prerelease && release.version.as_ref().is_some_and(|v| v.pre.as_str().split('.').any(|part| part.eq_ignore_ascii_case("nightly")))
}

/// Selects a published release. A nightly must be explicitly marked; a pin never falls back.
pub fn has_published_checksum(r: &Release) -> bool {
    r.sums_asset().is_some() || r.assets.iter().any(|a| a.sha256.is_some())
}

pub fn choose_version(releases: &[Release], track: &crate::protocol::VersionTrack) -> Option<Release> {
    use crate::protocol::VersionTrack;
    match track {
        VersionTrack::Stable => releases
            .iter()
            .filter(|r| !r.prerelease && r.version.as_ref().is_some_and(version::is_stable))
            .max_by(|a, b| a.version.cmp(&b.version))
            .cloned(),
        VersionTrack::Nightly => releases.iter().filter(|r| is_nightly(r) && has_published_checksum(r)).max_by_key(|r| r.published_at).cloned(),
        VersionTrack::Pinned(tag) => releases.iter().find(|r| r.tag == *tag).cloned(),
    }
}

/// Reads `GET /repos/<repo>/releases` and returns the newest stable (or any, with
/// `allow_prerelease`) published release.
pub fn parse_github_release_list(json: &str, repo: &str, allow_prerelease: bool) -> Result<Option<Release>, String> {
    let v: serde_json::Value = serde_json::from_str(json).map_err(|e| format!("unreadable answer from GitHub ({e})"))?;
    let list = v.as_array().ok_or("unexpected answer from GitHub")?;
    let mut best: Option<Release> = None;
    for item in list {
        if item["draft"].as_bool().unwrap_or(false) {
            continue;
        }
        let Ok(r) = release_from_value(item, repo) else { continue };
        let Some(ver) = r.version.as_ref() else { continue };
        if !allow_prerelease && (r.prerelease || !version::is_stable(ver)) {
            continue;
        }
        let newer = best.as_ref().and_then(|b| b.version.as_ref()).is_none_or(|b| version::is_newer(ver, b));
        if newer {
            best = Some(r);
        }
    }
    Ok(best)
}

fn release_from_value(v: &serde_json::Value, repo: &str) -> Result<Release, String> {
    if let Some(msg) = v["message"].as_str() {
        return Err(if msg == "Not Found" { "no releases yet".into() } else { format!("GitHub says: {}", truncate(msg, 200)) });
    }
    let tag = v["tag_name"].as_str().filter(|t| valid_tag(t)).ok_or("no release found")?.to_string();
    let releases = format!("https://github.com/{repo}/releases");
    let html_url = v["html_url"].as_str().and_then(|u| safe_release_html_url(repo, u)).unwrap_or_else(|| releases.clone());
    let prefix = download_prefix(repo);
    let assets = v["assets"]
        .as_array()
        .map(|list| {
            list.iter()
                .filter_map(|a| {
                    let name = a["name"].as_str().filter(|n| valid_file_name(n))?.to_string();
                    let url = a["browser_download_url"]
                        .as_str()
                        .filter(|u| download_url_under(u, &prefix) && *u == format!("{prefix}{tag}/{name}"))?
                        .to_string();
                    let sha256 = a["digest"].as_str().and_then(|d| d.strip_prefix("sha256:")).filter(|h| is_hex64(h)).map(str::to_ascii_lowercase);
                    Some(Asset { name, size: a["size"].as_u64().unwrap_or(0), url, sha256 })
                })
                .collect()
        })
        .unwrap_or_default();
    Ok(Release {
        version: version::parse(&tag),
        name: v["name"].as_str().map(|n| truncate(n, 120)).filter(|n| !n.is_empty()).unwrap_or_else(|| tag.clone()),
        tag,
        published_at: v["published_at"].as_str().and_then(crate::time::parse_rfc3339),
        html_url,
        notes: v["body"].as_str().map(|b| truncate(b, MAX_NOTES)).unwrap_or_default(),
        prerelease: v["prerelease"].as_bool().unwrap_or(false),
        assets,
    })
}

/// Reads a release from GitHub's quota-free release pages: the repository's releases Atom feed
/// (name, date and notes) and the `/releases/expanded_assets/<tag>` HTML (files and digests).
///
/// This is the route used when the REST API is out of quota or unreachable. `atom` may be
/// `None`; the release still installs from the asset list alone.
pub fn release_from_pages(repo: &str, tag: &str, atom: Option<&str>, assets_html: &str) -> Release {
    let mut release = Release {
        tag: tag.to_string(),
        version: version::parse(tag),
        name: tag.to_string(),
        published_at: None,
        html_url: format!("https://github.com/{repo}/releases/tag/{tag}"),
        notes: String::new(),
        prerelease: false,
        assets: parse_expanded_assets(assets_html, repo, tag),
    };
    if let Some(entry) = atom.and_then(|xml| atom_entry(xml, repo, tag)) {
        if let Some(title) = entry.title {
            let title = title.trim();
            if !title.is_empty() {
                release.name = truncate(title, 120);
            }
        }
        release.published_at = entry.updated;
        if let Some(url) = safe_release_html_url(repo, &entry.html_url) {
            release.html_url = url;
        }
        release.notes = truncate(&html_notes(&entry.content), MAX_NOTES);
    }
    release
}

struct AtomEntry {
    title: Option<String>,
    updated: Option<i64>,
    html_url: String,
    content: String,
}

/// The Atom entry whose alternate link points at `repo`'s `tag` release.
fn atom_entry(xml: &str, repo: &str, tag: &str) -> Option<AtomEntry> {
    let html_url = format!("https://github.com/{repo}/releases/tag/{tag}");
    let link = format!("href=\"{html_url}\"");
    let mut search = 0;
    while let Some(found) = xml[search..].find("<entry>") {
        let start = search + found + "<entry>".len();
        let end = xml[start..].find("</entry>").map(|n| start + n)?;
        let block = &xml[start..end];
        search = end + "</entry>".len();
        if !block.contains(&link) {
            continue;
        }
        let text_of = |name: &str| -> Option<String> {
            let open = format!("<{name}");
            let open_at = block.find(&open)?;
            let after = block[open_at..].find('>')? + open_at + 1;
            let close = format!("</{name}>");
            let end = block[after..].find(&close)? + after;
            Some(block[after..end].to_string())
        };
        return Some(AtomEntry {
            title: text_of("title").map(|t| decode_entities(&t)),
            updated: text_of("updated").and_then(|t| crate::time::parse_rfc3339(&t)),
            html_url: html_url.clone(),
            content: text_of("content").map(|c| decode_entities(&c)).unwrap_or_default(),
        });
    }
    None
}

/// The files listed by `https://github.com/<repo>/releases/expanded_assets/<tag>`.
///
/// Each row links to `/<repo>/releases/download/<tag>/<name>` and carries the published
/// `sha256:` digest. Sizes are only shown rounded on that page, so they stay 0 (unknown) and the
/// download takes the exact length from the server while verifying the digest.
pub fn parse_expanded_assets(html: &str, repo: &str, tag: &str) -> Vec<Asset> {
    let marker = format!("/{repo}/releases/download/{tag}/");
    let mut assets = Vec::new();
    let mut search = 0;
    while let Some(found) = html[search..].find(&marker) {
        let href_at = search + found;
        let name_at = href_at + marker.len();
        let tail = &html[name_at..];
        let Some(name_end) = tail.find(['"', '\'', '&']) else { break };
        let encoded = &tail[..name_end];
        let name = percent_decode(encoded);
        search = name_at + name_end;
        if !valid_file_name(&name) || assets.iter().any(|a: &Asset| a.name == name) {
            continue;
        }
        // The digest copy button follows the file name in the same row. Look only as far as the
        // next download link so one asset can never borrow its neighbour's digest.
        let next = html[search..].find(&marker).map_or(html.len(), |n| search + n);
        let window = &html[search..next.min(search.saturating_add(8192))];
        let sha256 =
            window.find("sha256:").and_then(|d| window[d + "sha256:".len()..].get(..64)).filter(|h| is_hex64(h)).map(str::to_ascii_lowercase);
        let url = format!("{}{tag}/{name}", download_prefix(repo));
        if download_url_under(&url, &download_prefix(repo)) {
            assets.push(Asset { name, size: 0, url, sha256 });
        }
    }
    assets
}

/// Decodes the percent escapes GitHub puts in asset links (`%20` and friends).
fn percent_decode(text: &str) -> String {
    let bytes = text.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%'
            && let Some(hex) = text.get(i + 1..i + 3)
            && let Ok(value) = u8::from_str_radix(hex, 16)
        {
            out.push(value);
            i += 3;
            continue;
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// Turns the HTML in a release Atom entry into the small Markdown subset `notes.rs` renders:
/// headings, bullets, bold, italics and code, with paragraphs kept apart.
fn html_notes(html: &str) -> String {
    let mut out = String::with_capacity(html.len());
    let mut i = 0;
    let mut text_at = 0;
    while i < html.len() {
        let Some(open) = html[i..].find('<').map(|n| i + n) else { break };
        push_text(&mut out, &decode_entities(&html[text_at..open]));
        let Some(close) = html[open..].find('>').map(|n| open + n) else { break };
        let raw = html[open + 1..close].trim();
        let closing = raw.starts_with('/');
        let name = raw.trim_start_matches('/').split_whitespace().next().unwrap_or("").to_ascii_lowercase();
        match (closing, name.as_str()) {
            (false, "h1" | "h2") => out.push_str("\n\n## "),
            (false, "h3" | "h4" | "h5" | "h6") => out.push_str("\n\n### "),
            (true, "h1" | "h2" | "h3" | "h4" | "h5" | "h6") => out.push('\n'),
            (false, "li") => out.push_str("\n- "),
            (false, "p" | "ul" | "ol" | "blockquote" | "div" | "details" | "summary") => out.push_str("\n\n"),
            (true, "p" | "ul" | "ol" | "blockquote" | "div" | "details") => out.push('\n'),
            (false, "br") => out.push('\n'),
            (false, "strong" | "b") => out.push_str("**"),
            (true, "strong" | "b") => out.push_str("**"),
            (false, "em" | "i") => out.push('*'),
            (true, "em" | "i") => out.push('*'),
            (false, "code") => out.push('`'),
            (true, "code") => out.push('`'),
            (false, "pre") => out.push_str("\n\n```\n"),
            (true, "pre") => out.push_str("\n```\n\n"),
            _ => {}
        }
        i = close + 1;
        text_at = i;
    }
    push_text(&mut out, &decode_entities(&html[text_at.min(html.len())..]));
    tidy_markdown(&out)
}

/// Appends visible text, collapsing runs of whitespace to one space. Newlines in the source are
/// layout, not line breaks; block tags add the only real breaks.
fn push_text(out: &mut String, text: &str) {
    for c in text.chars() {
        if c.is_whitespace() {
            if !out.is_empty() && !out.ends_with([' ', '\n']) {
                out.push(' ');
            }
        } else {
            out.push(c);
        }
    }
}

/// Trims each line, drops repeated blank lines and surrounding blanks.
fn tidy_markdown(text: &str) -> String {
    let mut lines: Vec<&str> = Vec::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() {
            if !lines.is_empty() && !matches!(lines.last(), Some(&"")) {
                lines.push("");
            }
        } else {
            lines.push(line);
        }
    }
    while lines.last() == Some(&"") {
        lines.pop();
    }
    lines.join("\n")
}

/// Decodes XML/HTML entities in feed text (`&lt;`, `&amp;`, `&#39;`, ...).
fn decode_entities(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(i) = rest.find('&') {
        out.push_str(&rest[..i]);
        let tail = &rest[i..];
        let entity = tail.find(';').filter(|end| *end <= 12).map(|end| (&tail[1..end], end));
        let decoded = entity.and_then(|(name, _)| match name {
            "lt" => Some('<'),
            "gt" => Some('>'),
            "amp" => Some('&'),
            "quot" => Some('"'),
            "apos" => Some('\''),
            "nbsp" => Some(' '),
            _ => name.strip_prefix('#').and_then(|num| {
                let value = match num.strip_prefix(['x', 'X']) {
                    Some(hex) => u32::from_str_radix(hex, 16).ok(),
                    None => num.parse().ok(),
                };
                value.and_then(char::from_u32)
            }),
        });
        match (decoded, entity) {
            (Some(c), Some((_, end))) => {
                out.push(c);
                rest = &tail[end + 1..];
            }
            _ => {
                out.push('&');
                rest = &tail[1..];
            }
        }
    }
    out.push_str(rest);
    out
}

/// A release known only from its tag and `SHA256SUMS.txt` (the quota-free route: the
/// `releases/latest` redirect names the tag, and the sums list every file).
pub fn release_from_sums(repo: &str, tag: &str, sums: &[(String, String)]) -> Release {
    let prefix = download_prefix(repo);
    let mut assets: Vec<Asset> = sums
        .iter()
        .map(|(hash, name)| Asset { name: name.clone(), size: 0, url: format!("{prefix}{tag}/{name}"), sha256: Some(hash.clone()) })
        .collect();
    assets.push(Asset { name: "SHA256SUMS.txt".into(), size: 0, url: format!("{prefix}{tag}/SHA256SUMS.txt"), sha256: None });
    Release {
        tag: tag.to_string(),
        version: version::parse(tag),
        name: tag.to_string(),
        published_at: None,
        html_url: format!("https://github.com/{repo}/releases/tag/{tag}"),
        notes: String::new(),
        prerelease: false,
        assets,
    }
}

/// The tag in a `https://github.com/<repo>/releases/tag/<tag>` redirect target.
pub fn tag_from_redirect(location: &str, repo: &str) -> Option<String> {
    let rest = location.strip_prefix(&format!("https://github.com/{repo}/releases/tag/"))?;
    valid_tag(rest).then(|| rest.to_string())
}

/// A release tag we'd put in a URL, a file or the UI: up to 64 of `[A-Za-z0-9._+-]`, not
/// starting with a dot, so no separators, control or bidi characters and no `.`/`..`.
pub fn valid_tag(tag: &str) -> bool {
    tag.len() <= 64 && !tag.starts_with('.') && plain_name(tag)
}

/// Non-empty and only `[A-Za-z0-9._+-]`, the characters every Craft release tag and asset uses.
fn plain_name(s: &str) -> bool {
    !s.is_empty() && s.bytes().all(|b| b.is_ascii_alphanumeric() || b"._-+".contains(&b))
}

/// Reads `sha256sum` output: `<hex>  <name>` (or `<hex> *<name>`) per line.
pub fn parse_sha256sums(text: &str) -> Vec<(String, String)> {
    text.lines()
        .filter_map(|line| {
            let (hash, rest) = line.trim().split_once(char::is_whitespace)?;
            let name = rest.trim_start().trim_start_matches('*');
            (is_hex64(hash) && valid_file_name(name)).then(|| (hash.to_ascii_lowercase(), name.to_string()))
        })
        .collect()
}

/// A bare file name we'd be willing to save: only `[A-Za-z0-9._+-]`, no leading or trailing dot,
/// and not a name Windows reserves for a device (`CON`, `nul.txt`, `COM1.msi`).
pub fn valid_file_name(name: &str) -> bool {
    name.len() <= 200 && !name.starts_with('.') && !name.ends_with('.') && plain_name(name) && !windows_device(name)
}

fn windows_device(name: &str) -> bool {
    let stem = name.split('.').next().unwrap_or_default().to_ascii_uppercase();
    matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || matches!(stem.as_bytes(), [b'C', b'O', b'M', b'1'..=b'9'] | [b'L', b'P', b'T', b'1'..=b'9'])
}

/// `s` cut to at most `max` bytes (on a char boundary) with an ellipsis, for text from a
/// release or the feed shown in the UI.
pub(crate) fn truncate(s: &str, max: usize) -> String {
    if s.len() <= max {
        return s.to_string();
    }
    let mut end = max;
    while !s.is_char_boundary(end) {
        end -= 1;
    }
    format!("{}…", &s[..end])
}

#[cfg(test)]
mod tests {
    use super::*;

    const REPO: &str = "storytold/photocraft";

    #[test]
    fn truncate_keeps_whole_characters() {
        assert_eq!(truncate("short", 10), "short");
        assert_eq!(truncate("abcdef", 3), "abc…");
        // `é` is two bytes: cutting at 2 would split it, so the cut backs off to 1.
        assert_eq!(truncate("aé", 2), "a…");
    }

    #[test]
    fn only_plain_https_links_pass() {
        assert!(safe_web_link("https://github.com/storytold/photocraft/releases/tag/v1"));
        for bad in [
            "http://example.com/",
            "javascript:alert(1)",
            "file:///C:/Windows/System32/calc.exe",
            "ms-msdt:/id",
            "https://",
            "https://user@evil.example/",
            "https://example.com/a b",
            "https://example.com/\nx",
            "https:///path",
            // Shell/cmd metacharacters: the WSL opener fallback shells out, so these must be
            // refused even inside an otherwise valid https URL (CWE-78).
            "https://example.com/a|calc",
            "https://example.com/p?x=1&y=2",
            "https://example.com/`id`",
            "https://example.com/$(whoami)",
            "https://example.com/a;b",
            "https://example.com/a>b",
            "https://example.com/%COMSPEC%",
            "https://example.com/%PATH%",
        ] {
            assert!(!safe_web_link(bad), "{bad:?}");
        }
    }
    const HASH: &str = "8a5edab282632443219e051e4ade2d1d5bbc671c781051bf1437897cbdfea0f1";

    fn api_json(url: &str) -> String {
        format!(
            r#"{{"tag_name":"v0.5.0","name":"PhotoCraft v0.5.0","html_url":"https://github.com/storytold/photocraft/releases/tag/v0.5.0",
            "published_at":"2026-10-08T14:52:50Z","prerelease":false,"body":"Notes",
            "assets":[{{"name":"photocraft-0.5.0-macos-universal.dmg","size":123,"browser_download_url":"{url}","digest":"sha256:{HASH}"}}]}}"#
        )
    }

    #[test]
    fn reads_the_latest_release() {
        let r = parse_github_release(
            &api_json("https://github.com/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0-macos-universal.dmg"),
            REPO,
        )
        .unwrap();
        assert_eq!(r.version, Some(Version::new(0, 5, 0)));
        assert_eq!(r.name, "PhotoCraft v0.5.0");
        assert_eq!(r.published_at, Some(1_791_471_170));
        assert_eq!(r.assets.len(), 1);
        assert_eq!(r.assets[0].sha256.as_deref(), Some(HASH));
        assert_eq!(r.assets[0].size, 123);
    }

    #[test]
    fn drops_downloads_that_point_elsewhere() {
        for url in ["https://evil.example/photocraft.dmg", "https://github.com/storytold/other/releases/download/v1/x.dmg", "javascript:alert(1)"] {
            let r = parse_github_release(&api_json(url), REPO).unwrap();
            assert!(r.assets.is_empty(), "{url}");
        }
        assert_eq!(parse_github_release(r#"{"message":"Not Found"}"#, REPO).unwrap_err(), "no releases yet");
        assert!(parse_github_release("<html>", REPO).is_err());
    }

    #[test]
    fn release_html_url_rejects_traversal_and_metacharacters() {
        let repo = "storytold/photocraft";
        assert_eq!(
            safe_release_html_url(repo, "https://github.com/storytold/photocraft/releases/tag/v1.0.0"),
            Some("https://github.com/storytold/photocraft/releases/tag/v1.0.0".to_string())
        );
        assert_eq!(
            safe_release_html_url(repo, "https://github.com/storytold/photocraft/releases"),
            Some("https://github.com/storytold/photocraft/releases".to_string())
        );
        for bad in [
            "https://github.com/storytold/photocraft/releases/../../attacker/repo/releases/tag/v1",
            "https://github.com/storytold/photocraft/releases/tag/v1/../../../attacker/repo",
            "https://github.com/storytold/photocraft/releases/tag/v1|calc.exe",
            "https://github.com/storytold/photocraft/releases/tag/v1%2f..%2f..",
            "https://github.com/storytold/photocraft/releases/tag/v1?x=1",
            "https://github.com/storytold/photocraft/releases/tag/v1#hash",
            "https://github.com/storytold/other/releases/tag/v1.0.0",
            "http://github.com/storytold/photocraft/releases/tag/v1",
        ] {
            assert!(safe_release_html_url(repo, bad).is_none(), "should reject: {bad}");
        }
    }

    #[test]
    fn selected_release_cannot_download_an_asset_from_a_different_tag() {
        let wrong_tag = "https://github.com/storytold/photocraft/releases/download/v9.0.0/photocraft-0.5.0-macos-universal.dmg";
        let r = parse_github_release(&api_json(wrong_tag), REPO).unwrap();
        assert!(r.assets.is_empty());
    }

    #[test]
    fn traversal_cannot_escape_the_repository() {
        // Raw-prefix matches but the interpreted path climbs into another repository (CWE-180).
        for url in [
            "https://github.com/storytold/photocraft/releases/download/../../../../attacker/repo/releases/download/v99/photocraft-99.0.0-linux-x86_64.AppImage",
            "https://github.com/storytold/photocraft/releases/download/v1/../../../attacker/repo/x.dmg",
            "https://github.com/storytold/photocraft/releases/download/./v1/x.dmg",
            "https://github.com/storytold/photocraft/releases/download/v1/sub/x.dmg",
            "https://github.com/storytold/photocraft/releases/download/v1%2f..%2f..%2fx.dmg",
            "https://github.com/storytold/photocraft/releases/download/v1/x%2fy.dmg",
        ] {
            let prefix = download_prefix(REPO);
            assert!(!download_url_under(url, &prefix), "{url}");
            let r = parse_github_release(&api_json(url), REPO).unwrap();
            assert!(r.assets.is_empty(), "{url}");
        }
        // A plain, confined download still passes.
        let prefix = download_prefix(REPO);
        assert!(download_url_under("https://github.com/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0-macos-universal.dmg", &prefix));
    }

    #[test]
    fn version_choices_exclude_drafts_and_distinguish_nightly_from_betas() {
        let json = r#"[
            {"tag_name":"v0.8.0-nightly.20261028","prerelease":true,"draft":false,"assets":[]},
            {"tag_name":"v0.8.0-beta.1","prerelease":true,"draft":false,"assets":[]},
            {"tag_name":"v0.7.0","prerelease":false,"draft":false,"assets":[]},
            {"tag_name":"v0.9.0-nightly.20261029","prerelease":true,"draft":true,"assets":[]},
            {"tag_name":"not-a-version","prerelease":false,"draft":false,"assets":[]}]"#;
        let choices = parse_github_versions(json, REPO).unwrap();
        assert_eq!(choices.iter().map(|r| r.tag.as_str()).collect::<Vec<_>>(), ["v0.8.0-nightly.20261028", "v0.8.0-beta.1", "v0.7.0"]);
        assert!(is_nightly(&choices[0]));
        assert!(!is_nightly(&choices[1]));
        assert!(!is_nightly(&choices[2]));
    }

    #[test]
    fn a_nightly_without_published_checksums_is_unavailable() {
        let mut nightly = Release {
            tag: "v1.1.0-nightly.20261028".into(),
            version: crate::version::parse("v1.1.0-nightly.20261028"),
            prerelease: true,
            ..Default::default()
        };
        nightly.assets.push(Asset { name: "app.zip".into(), size: 3, url: "https://example.invalid/app.zip".into(), sha256: None });
        assert!(choose_version(&[nightly], &crate::protocol::VersionTrack::Nightly).is_none());
    }

    #[test]
    fn selection_follows_nightly_or_pins_an_older_release_without_beta_fallback() {
        use crate::protocol::VersionTrack;
        let json = r#"[
            {"tag_name":"v0.8.0-nightly.20261028","prerelease":true,"published_at":"2026-10-28T10:00:00Z"},
            {"tag_name":"v0.8.0-beta.1","prerelease":true,"published_at":"2026-10-28T12:00:00Z"},
            {"tag_name":"v0.8.0-nightly.20261027","prerelease":true,"published_at":"2026-10-27T10:00:00Z"},
            {"tag_name":"v0.7.0","prerelease":false},
            {"tag_name":"v0.6.0","prerelease":false}]"#;
        let mut list = parse_github_versions(json, REPO).unwrap();
        for r in list.iter_mut().filter(|r| is_nightly(r)) {
            r.assets.push(Asset { name: "app.zip".into(), size: 3, url: "https://example.invalid/app.zip".into(), sha256: Some(HASH.into()) });
        }
        assert_eq!(choose_version(&list, &VersionTrack::Stable).unwrap().tag, "v0.7.0");
        assert_eq!(choose_version(&list, &VersionTrack::Nightly).unwrap().tag, "v0.8.0-nightly.20261028");
        assert_eq!(choose_version(&list, &VersionTrack::Pinned("v0.6.0".into())).unwrap().tag, "v0.6.0");
        assert!(choose_version(&list, &VersionTrack::Pinned("v9.0.0".into())).is_none());
        assert!(choose_version(&list[3..], &VersionTrack::Nightly).is_none());
    }

    #[test]
    fn list_picks_the_newest_stable_release() {
        let json = r#"[
            {"tag_name":"v0.6.0-rc.1","prerelease":false,"draft":false,"assets":[]},
            {"tag_name":"v0.5.1","prerelease":true,"draft":false,"assets":[]},
            {"tag_name":"v0.7.0","draft":true,"assets":[]},
            {"tag_name":"v0.5.0","prerelease":false,"draft":false,"assets":[]},
            {"tag_name":"v0.4.0","prerelease":false,"draft":false,"assets":[]}]"#;
        assert_eq!(parse_github_release_list(json, REPO, false).unwrap().unwrap().tag, "v0.5.0");
        assert_eq!(parse_github_release_list(json, REPO, true).unwrap().unwrap().tag, "v0.6.0-rc.1");
        assert_eq!(parse_github_release_list("[]", REPO, false).unwrap(), None);
    }

    #[test]
    fn reads_checksums_and_redirects() {
        let sums = parse_sha256sums(&format!("{HASH}  photocraft-0.5.0-macos-universal.dmg\n{HASH} *b.zip\nnot a line\n{HASH}  ../escape\n"));
        assert_eq!(sums, [(HASH.to_string(), "photocraft-0.5.0-macos-universal.dmg".to_string()), (HASH.to_string(), "b.zip".to_string())]);
        assert_eq!(tag_from_redirect("https://github.com/storytold/photocraft/releases/tag/v0.5.0", REPO).as_deref(), Some("v0.5.0"));
        assert_eq!(tag_from_redirect("https://github.com/storytold/photocraft/releases", REPO), None);
        assert_eq!(tag_from_redirect("https://evil/storytold/photocraft/releases/tag/v1", REPO), None);
        let r = release_from_sums(REPO, "v0.5.0", &sums);
        assert_eq!(r.assets[0].url, "https://github.com/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0-macos-universal.dmg");
        assert_eq!(r.version, Some(Version::new(0, 5, 0)));
    }

    #[test]
    fn file_names_cannot_escape() {
        for bad in [
            "",
            "..",
            "a/b",
            "a\\b",
            ".hidden",
            "c:x",
            "x\u{0}",
            "a b.dmg",
            "a%2e.msi",
            "a#b",
            "evil\u{202e}gpj.exe",
            "x.msi.",
            "CON",
            "nul.txt",
            "COM1.msi",
            "lpt9",
            "prn",
            "aux.log",
            "a".repeat(201).as_str(),
        ] {
            assert!(!valid_file_name(bad), "{bad:?}");
        }
        for good in [
            "photocraft-0.5.0-linux-x86_64.AppImage",
            "lightcraft_0.9.0_amd64.deb",
            "x-1.0+git.tar.gz",
            "console.zip",
            "COM10.txt",
            "COM0.msi",
            "lpt0",
        ] {
            assert!(valid_file_name(good), "{good:?}");
        }
    }

    #[test]
    fn tags_are_plain() {
        for good in ["v0.6.0", "v1.0.0-beta.2", "nightly-2026-10-29", "v1+build.7"] {
            assert!(valid_tag(good), "{good:?}");
        }
        for bad in ["", ".", "..", ".v1", "v1/x", "v1\\x", "v1\nx", "v1\u{0}x", "v1\u{202e}", "v 1", "v1?x", "v".repeat(65).as_str()] {
            assert!(!valid_tag(bad), "{bad:?}");
        }
        let api = r#"{"tag_name": "v1\u202egpj", "html_url": "", "assets": []}"#;
        assert!(parse_github_release(api, REPO).is_err());
        let prefix = download_prefix(REPO);
        assert!(download_url_under(&format!("{prefix}v1/a.dmg"), &prefix));
        assert!(!download_url_under(&format!("{prefix}v1\u{202e}/a.dmg"), &prefix), "an odd tag in a download link");
        assert!(!download_url_under(&format!("{prefix}v1/a\u{202e}.dmg"), &prefix), "an odd name in a download link");
        assert_eq!(tag_from_redirect(&format!("https://github.com/{REPO}/releases/tag/v1\u{202e}"), REPO), None);
    }

    #[test]
    fn release_pages_give_the_tag_notes_and_digests() {
        let atom = r#"<?xml version="1.0" encoding="UTF-8"?>
            <feed xmlns="http://www.w3.org/2005/Atom">
              <entry>
                <id>tag:github.com,2008:Repository/1/v0.5.0</id>
                <updated>2026-11-11T22:01:37Z</updated>
                <link rel="alternate" type="text/html" href="https://github.com/storytold/photocraft/releases/tag/v0.5.0"/>
                <title>PhotoCraft 0.5.0</title>
                <content type="html">&lt;h2&gt;What&#39;s new&lt;/h2&gt;
&lt;ul&gt;
&lt;li&gt;&lt;strong&gt;Faster&lt;/strong&gt; export&lt;/li&gt;
&lt;li&gt;Paste pictures &amp;amp; files&lt;/li&gt;
&lt;/ul&gt;</content>
              </entry>
            </feed>"#;
        let assets = r#"
            <ul><li>
              <a href="/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0.apk" rel="nofollow">
                <span class="text-bold">photocraft-0.5.0.apk</span>
              </a>
              <clipboard-copy value="sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"></clipboard-copy>
              <span>388 MB</span>
            </li><li>
              <a href="/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0.dmg" rel="nofollow">
                <span class="text-bold">photocraft-0.5.0.dmg</span>
              </a>
            </li><li>
              <a href="/storytold/photocraft/releases/download/v0.5.0/SHA256SUMS.txt" rel="nofollow">
                <span class="text-bold">SHA256SUMS.txt</span>
              </a>
              <clipboard-copy value="sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"></clipboard-copy>
            </li></ul>"#;
        let release = release_from_pages(REPO, "v0.5.0", Some(atom), assets);
        assert_eq!(release.name, "PhotoCraft 0.5.0");
        assert_eq!(release.version, Some(Version::new(0, 5, 0)));
        assert_eq!(release.published_at, crate::time::parse_rfc3339("2026-11-11T22:01:37Z"));
        assert_eq!(release.assets.len(), 3);
        assert_eq!(release.assets[0].name, "photocraft-0.5.0.apk");
        assert_eq!(release.assets[0].sha256.as_deref(), Some("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        assert_eq!(release.assets[1].sha256, None);
        assert_eq!(release.assets[2].sha256.as_deref(), Some("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"));
        assert_eq!(release.assets[0].url, "https://github.com/storytold/photocraft/releases/download/v0.5.0/photocraft-0.5.0.apk");
        assert_eq!(release.notes, "## What's new\n\n- **Faster** export\n- Paste pictures & files");
    }

    #[test]
    fn release_pages_survive_a_missing_atom() {
        let assets = r#"<a href="/storytold/photocraft/releases/download/v1.0.0/a.apk">a</a>"#;
        let release = release_from_pages(REPO, "v1.0.0", None, assets);
        assert_eq!(release.name, "v1.0.0");
        assert_eq!(release.notes, "");
        assert_eq!(release.assets[0].name, "a.apk");
        // A page for another tag must not lend its files to this release.
        assert_eq!(release_from_pages(REPO, "v1.0.1", None, assets).assets.len(), 0);
        assert_eq!(release_from_pages(REPO, "v1.0.0", None, r#"<a href="/evil/x/releases/download/v1.0.0/a.apk">a</a>"#).assets.len(), 0);
    }
}
